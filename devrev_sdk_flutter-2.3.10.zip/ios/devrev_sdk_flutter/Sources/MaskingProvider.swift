import Foundation
import Flutter
import DevRevSDK

class MaskingProvider: NSObject, ScreenTransitionDelegate, DevRev.MaskLocationProviding {
	// MARK: - Properties

	private let stateLock = NSLock()
	private var methodChannel: FlutterMethodChannel?
	private var isEngineAttached = false
	/// True after a fetch returns non-empty mask locations; cleared on detach, reset, or navigation end.
	private var isDartSideReady = false
	private var _isScreenTranistioning = false

	var isScreenTranistioning: Bool {
		get {
			withStateLock { _isScreenTranistioning }
		}
		set {
			withStateLock { _isScreenTranistioning = newValue }
			if !newValue {
				invalidateDartSideReady()
			}
		}
	}

	// MARK: - Lifecycle

	override init() {
		super.init()
		DevRev.setMaskingLocationProvider(self)
	}

	func attach(methodChannel: FlutterMethodChannel) {
		withStateLock {
			self.methodChannel = methodChannel
			isEngineAttached = true
			isDartSideReady = false
		}
	}

	func detach() {
		withStateLock {
			isEngineAttached = false
			isDartSideReady = false
			methodChannel = nil
			_isScreenTranistioning = false
		}
	}

	func resetDartMaskingState() {
		invalidateDartSideReady()
	}

	// MARK: - Masking

	func fetchMaskLocations(
		completionHandler: @escaping @Sendable (SnapshotMask) -> Void
	) {
		guard let methodChannel = activeMethodChannelForFetch() else {
			completionHandler(.init(
				locations: [],
				shouldSkip: true
			))
			return
		}

		let wasDartSideReady = withStateLock { isDartSideReady }

		methodChannel.invokeMethod(
			"fetchFlutterData",
			arguments: ["mode": "basic"]
		) { result in
			guard
				!self.isScreenTranistioning,
				let payload = result as? [String: Any],
				let locations = payload["locations"] as? Array<Dictionary<String, String>>
			else {
				completionHandler(.init(
					locations: [],
					shouldSkip: self.isScreenTranistioning
				))
				return
			}

			let hasMasksRegistered = payload["hasMasksRegistered"] as? Bool ?? false
			var snapshotMaskLocations = [SnapshotMask.Location]()

			for location in locations {
				guard
					let stringX = location["x"],
					let stringY = location["y"],
					let stringWidth = location["width"],
					let stringHeight = location["height"],
					let doubleX = Double(stringX),
					let doubleY = Double(stringY),
					let doubleWidth = Double(stringWidth),
					let doubleHeight = Double(stringHeight)
				else {
					continue
				}

				let maskRect = CGRect(
					x: CGFloat(doubleX),
					y: CGFloat(doubleY),
					width: CGFloat(doubleWidth),
					height: CGFloat(doubleHeight)
				)

				snapshotMaskLocations.append(.init(location: maskRect))
			}

			completionHandler(
				self.makeSnapshotMask(
					locations: snapshotMaskLocations,
					hasMasksRegistered: hasMasksRegistered,
					wasDartSideReady: wasDartSideReady
				)
			)
		}
	}

	func provideSnapshotMask() async -> SnapshotMask {
		guard !isScreenTranistioning else {
			return .init(
				locations: [],
				shouldSkip: true
			)
		}

		guard activeMethodChannelForFetch() != nil else {
			return .init(
				locations: [],
				shouldSkip: true
			)
		}

		return await withCheckedContinuation { continuation in
			fetchMaskLocations { mask in
				continuation.resume(returning: mask)
			}
		}
	}

	// MARK: - Private

	private func withStateLock<T>(_ body: () -> T) -> T {
		stateLock.lock()
		defer { stateLock.unlock() }
		return body()
	}

	private func invalidateDartSideReady() {
		withStateLock {
			isDartSideReady = false
		}
	}

	/// Channel is usable for mask fetches when the engine is attached, regardless of prior readiness.
	private func activeMethodChannelForFetch() -> FlutterMethodChannel? {
		withStateLock {
			guard isEngineAttached 
			else {
				return nil
			}

			return methodChannel
		}
	}

	private func makeSnapshotMask(
		locations: [SnapshotMask.Location],
		hasMasksRegistered: Bool,
		wasDartSideReady: Bool
	) -> SnapshotMask {
		let isEmpty = locations.isEmpty

		if isEmpty {
			invalidateDartSideReady()
		} else {
			withStateLock {
				isDartSideReady = true
			}
		}

		// Skip when masks are registered but coords are not ready yet, or when a prior
		// session left stale readiness (e.g. hot restart before DevRevMask widgets mount).
		let shouldSkip =
			isScreenTranistioning
			|| (isEmpty && (hasMasksRegistered || wasDartSideReady))

		return .init(
			locations: locations,
			shouldSkip: shouldSkip
		)
	}
}
