import 'dart:io';
import 'devrev.dart';
import '../src/internal/mask_location.dart';
import '../src/internal/mask_controller.dart';
import '../src/internal/mask_global_key.dart';
import 'package:flutter/material.dart';
import 'dart:async';

typedef MaskRegisteredCallback = void Function(
    String uuid, MaskLocation location);
typedef MaskUpdatedCallback = void Function(String uuid, MaskLocation location);
typedef MaskDeregisteredCallback = void Function(String uuid);

abstract class _BaseMaskWidget extends StatefulWidget {
  final Widget child;
  final MaskRegisteredCallback onMaskRegistered;
  final MaskUpdatedCallback onMaskUpdated;
  final MaskDeregisteredCallback onMaskDeregistered;

  const _BaseMaskWidget({
    super.key,
    required this.child,
    required this.onMaskRegistered,
    required this.onMaskUpdated,
    required this.onMaskDeregistered,
  });
}

abstract class _BaseMaskState<T extends _BaseMaskWidget> extends State<T>
    with WidgetsBindingObserver {
  late final MaskGlobalKey _maskGlobalKey = MaskGlobalKey();
  Rect _previousLocation = Rect.zero;
  Timer? _debounceTimer;
  bool _isRegisteredWithController = false;

  MaskLocation get location =>
      MaskLocation(uuid: _maskGlobalKey.uuid, rect: _cachedGlobalBounds);

  Rect get _cachedGlobalBounds =>
      mounted ? _maskGlobalKey.globalBounds : Rect.zero;

  @override
  void initState() {
    super.initState();

    // Ensure that the DevRev SDK is configured before proceeding.
    if (!DevRev.isSDKConfigured) {
      debugPrint(
        'DevRev SDK is not configured. Please call DevRev.configure() before using DevRevMask or DevRevUnmask.',
      );
      return;
    }

    final loc = location;
    if (_previousLocation == Rect.zero) {
      _previousLocation = loc.rect;
    }

    widget.onMaskRegistered(_maskGlobalKey.uuid, loc);
    MaskController.instance
        .attachMaskMeasurer(_maskGlobalKey.uuid, _measureNow);
    _isRegisteredWithController = true;
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _attachToEnclosingRoute();
      _updateRecursivelyIfNeeded(Duration.zero);
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounceTimer?.cancel();
    if (_isRegisteredWithController) {
      widget.onMaskDeregistered(_maskGlobalKey.uuid);
      _isRegisteredWithController = false;
    }
    super.dispose();
  }

  // Debounce to delay the action and avoid excessive calls.
  void _debounce(VoidCallback action, Duration duration) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(duration, action);
  }

  // Visible unless an ancestor Visibility hides it or the route is covered.
  bool get _isVisible {
    if (!mounted) return false;
    if (!Visibility.of(context)) return false;
    final route = ModalRoute.of(context);
    if (route == null) return true;
    return !MaskController.instance.isRouteCoveredOrNested(route);
  }

  void _attachToEnclosingRoute() {
    if (!mounted) return;
    MaskController.instance
        .attachMaskToRoute(_maskGlobalKey.uuid, ModalRoute.of(context));
  }

  /// Measures on demand instead of serving the debounced rect, which always
  /// describes an earlier frame.
  MaskLocation? _measureNow() {
    if (!mounted) return null;
    final bounds = _maskGlobalKey.globalBounds;
    if (bounds == Rect.zero) return null;
    return _adjustLocationForLandscape(
      MaskLocation(uuid: _maskGlobalKey.uuid, rect: bounds),
    );
  }

  void _updateRecursivelyIfNeeded(Duration _) {
    if (!mounted) return;

    final visible = _isVisible;
    if (!visible && _isRegisteredWithController) {
      widget.onMaskDeregistered(_maskGlobalKey.uuid);
      _isRegisteredWithController = false;
    } else if (visible && !_isRegisteredWithController) {
      widget.onMaskRegistered(_maskGlobalKey.uuid, location);
      MaskController.instance
          .attachMaskMeasurer(_maskGlobalKey.uuid, _measureNow);
      _attachToEnclosingRoute();
      _isRegisteredWithController = true;
      _previousLocation = Rect.zero;
    }

    if (visible && _isRegisteredWithController) {
      MaskLocation currentLocation = location;
      if (currentLocation.rect != _previousLocation) {
        currentLocation = _adjustLocationForLandscape(currentLocation);
        _previousLocation = currentLocation.rect;
        widget.onMaskUpdated(_maskGlobalKey.uuid, currentLocation);
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateRecursivelyIfNeeded(Duration.zero);
    });
  }

  void _updateLocationAndTransitionState(Duration _) {
    // Skip covered routes so metrics/lifecycle paths don't re-insert stale rects.
    if (_isVisible) {
      MaskLocation currentLocation = location;
      if (currentLocation.rect != _previousLocation) {
        currentLocation = _adjustLocationForLandscape(currentLocation);
        _previousLocation = currentLocation.rect;
        widget.onMaskUpdated(_maskGlobalKey.uuid, currentLocation);
      }
    }

    // Enable frame capture at the native SDK after a short delay.
    _debounce(
      () => DevRev.updateTransitioningState(false),
      const Duration(milliseconds: 200),
    );
  }

  /// Widens the mask on Android in landscape, where it needs extra width on the
  /// right to cover the whole masked area.
  MaskLocation _adjustLocationForLandscape(MaskLocation location) {
    if (Platform.isAndroid) {
      if (!mounted) return location;

      if (MediaQuery.of(context).orientation == Orientation.landscape) {
        return MaskLocation(
          uuid: location.uuid,
          rect: Rect.fromLTRB(
            location.rect.left,
            location.rect.top,
            location.rect.right + 50, // Adjust width for landscape.
            location.rect.bottom,
          ),
        );
      }
    }
    return location;
  }

  @override
  KeyedSubtree build(BuildContext context) =>
      KeyedSubtree(key: _maskGlobalKey, child: widget.child);

  @override
  void didChangeMetrics() {
    // Disable the frame capture at the native SDK when the metrics change.
    DevRev.updateTransitioningState(true);

    WidgetsBinding.instance.addPostFrameCallback(
      _updateLocationAndTransitionState,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DevRev.updateTransitioningState(true);
      WidgetsBinding.instance.addPostFrameCallback(
        _updateLocationAndTransitionState,
      );
    }
  }
}

class DevRevMask extends _BaseMaskWidget {
  DevRevMask({super.key, required super.child})
      : super(
          onMaskRegistered: MaskController.instance.registerMask,
          onMaskUpdated: MaskController.instance.updateMask,
          onMaskDeregistered: MaskController.instance.deregisterMask,
        );

  @override
  State<DevRevMask> createState() => _DevRevMaskState();
}

class _DevRevMaskState extends _BaseMaskState<DevRevMask> {}

class DevRevUnmask extends _BaseMaskWidget {
  DevRevUnmask({super.key, required super.child})
      : super(
          onMaskRegistered: MaskController.instance.registerUnmask,
          onMaskUpdated: MaskController.instance.updateUnmask,
          onMaskDeregistered: MaskController.instance.deregisterUnmask,
        );

  @override
  State<DevRevUnmask> createState() => _DevRevUnmaskState();
}

class _DevRevUnmaskState extends _BaseMaskState<DevRevUnmask> {}
