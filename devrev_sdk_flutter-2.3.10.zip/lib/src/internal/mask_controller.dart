import 'package:flutter/widgets.dart';
import 'mask_location.dart';

/// Measures a mask's bounds now, or null when it cannot be measured.
typedef MaskMeasurer = MaskLocation? Function();

/// Controller for managing mask and unmask widget locations.
class MaskController {
  MaskController._();
  static final MaskController instance = MaskController._();

  final Map<String, MaskLocation> _masks = {};
  final Map<String, MaskLocation> _unmasks = {};
  VoidCallback? _onLocationsReady;

  /// Route whose masks [_onLocationsReady] is waiting on, if it was scoped.
  WeakReference<Route<dynamic>>? _readyDestination;

  final Map<String, MaskMeasurer> _maskMeasurers = {};

  // Expando so entries drop when a route is GC'd; nested Navigators skip didPop.
  final Expando<bool> _coveredRoutes = Expando<bool>('coveredRoutes');

  // Weak so a stranded entry cannot retain its Route and Element tree.
  final Map<String, WeakReference<Route<dynamic>>> _maskRoutes = {};

  void setRouteCovered(Route<dynamic> route, bool covered) {
    _coveredRoutes[route] = covered ? true : null;
  }

  bool isRouteCovered(Route<dynamic> route) => _coveredRoutes[route] ?? false;

  /// Guards against a cycle in the tree; no real layout nests this deeply.
  static const int _maxNavigatorDepth = 32;

  /// Walks [route] and every route enclosing it, innermost first, so a nested
  /// navigator's page resolves up to the shell route the observer can see.
  Iterable<Route<dynamic>> _routeAndEnclosing(Route<dynamic> route) sync* {
    Route<dynamic>? current = route;
    for (var depth = 0; depth < _maxNavigatorDepth; depth++) {
      if (current == null) return;
      yield current;
      // The navigator's context sits inside its route, so this exits the stack.
      final navigatorContext = current.navigator?.context;
      if (navigatorContext == null) return;
      final enclosing = ModalRoute.of(navigatorContext);
      if (enclosing == null || identical(enclosing, current)) return;
      current = enclosing;
    }
  }

  /// True when [route] is covered, or nested inside a covered shell route.
  bool isRouteCoveredOrNested(Route<dynamic> route) =>
      _routeAndEnclosing(route).any(isRouteCovered);

  /// True when [route] is [ancestor] itself, or sits inside a navigator on it.
  bool _isRouteWithin(Route<dynamic> route, Route<dynamic> ancestor) =>
      _routeAndEnclosing(route)
          .any((enclosing) => identical(enclosing, ancestor));

  void forgetRoute(Route<dynamic> route) {
    _coveredRoutes[route] = null;
    _maskRoutes
        .removeWhere((_, ref) => ref.target == null || ref.target == route);
  }

  /// Registers how to measure [uuid]'s bounds on demand, kept separate from
  /// [registerMask] because the mask callback typedefs are public API.
  void attachMaskMeasurer(String uuid, MaskMeasurer measurer) {
    // Unmasks call this too, but are never sent to native.
    if (!_masks.containsKey(uuid)) return;
    _maskMeasurers[uuid] = measurer;
  }

  /// Falls back to the cached rect rather than dropping the mask; a one-frame-old
  /// rect still covers most of the region.
  MaskLocation _currentLocation(String uuid, MaskLocation cached) {
    final measurer = _maskMeasurers[uuid];
    if (measurer == null) return cached;
    try {
      final measured = measurer();
      if (measured == null || !measured.isValid) return cached;
      return measured;
    } catch (e) {
      debugPrint('MaskController: Failed to measure mask $uuid. Error: $e');
      return cached;
    }
  }

  /// Records [uuid]'s route so readiness can ignore dead or covered routes.
  void attachMaskToRoute(String uuid, Route<dynamic>? route) {
    if (!_masks.containsKey(uuid)) return;
    if (route == null) {
      _maskRoutes.remove(uuid);
    } else {
      _maskRoutes[uuid] = WeakReference(route);
    }
    // Scoping may be what makes the remaining masks ready.
    _checkAndNotify();
  }

  /// Fails open: counting a dead mask as live only delays resume, but excluding
  /// a live one resumes with its field unmeasured.
  bool _isMaskMeasurable(String uuid) {
    final ref = _maskRoutes[uuid];
    if (ref == null) return true;
    final route = ref.target;
    if (route == null) return true;
    return route.isActive && !isRouteCoveredOrNested(route);
  }

  void registerMask(String uuid, MaskLocation location) {
    try {
      _masks[uuid] = location;
      _checkAndNotify();
    } catch (e) {
      debugPrint(
        'MaskController: Failed to register mask with UUID $uuid. Error: $e',
      );
    }
  }

  void deregisterMask(String uuid) {
    try {
      _masks.remove(uuid);
      _maskRoutes.remove(uuid);
      _maskMeasurers.remove(uuid);
      // Removing an unresolved mask can be what satisfies readiness.
      _checkAndNotify();
    } catch (e) {
      debugPrint(
        'MaskController: Failed to deregister mask with UUID $uuid. Error: $e',
      );
    }
  }

  void updateMask(String uuid, MaskLocation location) {
    try {
      _masks[uuid] = location;
      _checkAndNotify();
    } catch (e) {
      debugPrint(
        'MaskController: Failed to update mask with UUID $uuid. Error: $e',
      );
    }
  }

  void registerUnmask(String uuid, MaskLocation location) {
    try {
      _unmasks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to register unmask with UUID $uuid. Error: $e',
      );
    }
  }

  void deregisterUnmask(String uuid) {
    try {
      _unmasks.remove(uuid);
    } catch (e) {
      debugPrint(
        'MaskController: Failed to deregister unmask with UUID $uuid. Error: $e',
      );
    }
  }

  void updateUnmask(String uuid, MaskLocation location) {
    try {
      _unmasks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to update unmask with UUID $uuid. Error: $e',
      );
    }
  }

  /// Excludes masks on a popped or covered route; waiting on one suppresses
  /// capture forever.
  Iterable<MaskLocation> get _measurableMasks => _masks.entries
      .where((entry) => _isMaskMeasurable(entry.key))
      .map((entry) => entry.value);

  /// Native reads "registered but no rects" as skip-the-frame, so this must be
  /// scoped like readiness or a stranded mask stalls capture.
  bool get hasMasksRegistered => _measurableMasks.isNotEmpty;

  bool _locationsReadyOn(Route<dynamic>? destination) {
    if (destination != null) {
      if (_hasUnattachedMask) return false;
      return _masksOnRoute(destination)
          .every((loc) => loc.isValid && loc.rect != Rect.zero);
    }
    final masks = _measurableMasks;
    return masks.isNotEmpty &&
        masks.every((loc) => loc.isValid && loc.rect != Rect.zero);
  }

  bool get _hasUnattachedMask =>
      _masks.keys.any((uuid) => _maskRoutes[uuid]?.target == null);

  /// Masks mounted on [route], or inside a navigator that sits on it.
  Iterable<MaskLocation> _masksOnRoute(Route<dynamic> route) =>
      _masks.entries.where((entry) {
        final target = _maskRoutes[entry.key]?.target;
        if (target == null) return false;
        return _isRouteWithin(target, route);
      }).map((entry) => entry.value);

  void notifyWhenReady(VoidCallback callback, {Route<dynamic>? destination}) {
    _readyDestination =
        destination == null ? null : WeakReference<Route<dynamic>>(destination);
    if (_locationsReadyOn(_readyDestination?.target)) {
      _readyDestination = null;
      callback();
    } else {
      _onLocationsReady = callback;
    }
  }

  void cancelNotifyWhenReady() {
    _onLocationsReady = null;
    _readyDestination = null;
  }

  void _checkAndNotify() {
    if (_onLocationsReady != null &&
        _locationsReadyOn(_readyDestination?.target)) {
      final cb = _onLocationsReady!;
      _onLocationsReady = null;
      _readyDestination = null;
      cb();
    }
  }

  /// Returns all valid mask locations, excluding unmasked ones.
  ///
  /// Bounds are measured at call time so the rects bind to the frame native is
  /// about to capture, and are never scoped to measurable masks: over-reporting
  /// paints an extra box, while dropping one records real content bare.
  Map<String, dynamic> getLocations() {
    try {
      final locations = _masks.entries
          .map((entry) => _currentLocation(entry.key, entry.value))
          .where(
            (location) => location.isValid && location.rect != Rect.zero,
          )
          .map((location) => location.toJson)
          .whereType<Map<String, String>>()
          .toList();
      return {
        'locations': locations,
        'hasMasksRegistered': hasMasksRegistered,
      };
    } catch (e) {
      debugPrint(
        'MaskController: Error retrieving batched mask locations. Error: $e',
      );
      return {'locations': [], 'hasMasksRegistered': hasMasksRegistered};
    }
  }
}
