import 'dart:async';

import 'package:flutter/material.dart';
import '../../devrev.dart';
import 'src/internal/mask_controller.dart';

class DevRevMonitoredApp extends MaterialApp {
  DevRevMonitoredApp({
    super.key,
    super.navigatorKey,
    super.scaffoldMessengerKey,
    super.home,
    super.routes,
    super.initialRoute,
    super.onGenerateRoute,
    super.onGenerateInitialRoutes,
    super.onUnknownRoute,
    List<NavigatorObserver> navigatorObservers = const [],
    Widget Function(BuildContext, Widget?)? builder,
    super.title,
    super.onGenerateTitle,
    super.color,
    super.theme,
    super.darkTheme,
    super.highContrastTheme,
    super.highContrastDarkTheme,
    super.themeMode,
    super.themeAnimationDuration,
    super.themeAnimationCurve,
    super.locale,
    super.localizationsDelegates,
    super.localeListResolutionCallback,
    super.localeResolutionCallback,
    super.supportedLocales,
    super.debugShowMaterialGrid,
    super.showPerformanceOverlay,
    super.checkerboardRasterCacheImages,
    super.checkerboardOffscreenLayers,
    super.showSemanticsDebugger,
    super.debugShowCheckedModeBanner,
    super.shortcuts,
    super.actions,
    super.restorationScopeId,
    // Kept for backward compatibility with older Flutter versions, but not passed to super
    // to avoid deprecation warnings in Flutter 3.7.0+ (parameter is ignored by MaterialApp)
    bool useInheritedMediaQuery = false,
  }) : super(
          builder: (context, child) {
            Widget content = builder != null
                ? builder(context, child)
                : child ?? const SizedBox.shrink();
            return NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  DevRev.updateTransitioningState(true);
                } else if (notification is ScrollEndNotification) {
                  DevRev.updateTransitioningState(false);
                }
                return false;
              },
              child: content,
            );
          },
          navigatorObservers: [
            DevRevTransitionTrackingObserver(),
            ...navigatorObservers,
          ],
        );

  DevRevMonitoredApp.router({
    super.key,
    super.scaffoldMessengerKey,
    super.routerConfig,
    super.routeInformationProvider,
    super.routeInformationParser,
    super.routerDelegate,
    super.backButtonDispatcher,
    Widget Function(BuildContext, Widget?)? builder,
    super.title,
    super.onGenerateTitle,
    super.color,
    super.theme,
    super.darkTheme,
    super.highContrastTheme,
    super.highContrastDarkTheme,
    super.themeMode,
    super.themeAnimationDuration,
    super.themeAnimationCurve,
    super.locale,
    super.localizationsDelegates,
    super.localeListResolutionCallback,
    super.localeResolutionCallback,
    super.supportedLocales,
    super.debugShowMaterialGrid,
    super.showPerformanceOverlay,
    super.checkerboardRasterCacheImages,
    super.checkerboardOffscreenLayers,
    super.showSemanticsDebugger,
    super.debugShowCheckedModeBanner,
    super.shortcuts,
    super.actions,
    super.restorationScopeId,
    // Kept for backward compatibility with older Flutter versions, but not passed to super
    // to avoid deprecation warnings in Flutter 3.7.0+ (parameter is ignored by MaterialApp)
    bool useInheritedMediaQuery = false,
  }) : super.router(
          builder: (context, child) {
            Widget content = builder != null
                ? builder(context, child)
                : child ?? const SizedBox.shrink();
            return NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  DevRev.updateTransitioningState(true);
                } else if (notification is ScrollEndNotification) {
                  DevRev.updateTransitioningState(false);
                }
                return false;
              },
              child: content,
            );
          },
        );
}

/// A NavigatorObserver that tracks route transitions and updates the DevRev SDK
/// transitioning state accordingly.
///
/// This observer should be added to GoRouter's `observers` list when using
/// `DevRevMonitoredApp.router` with GoRouter to ensure proper transition tracking.
///
/// Example:
/// ```dart
/// final router = GoRouter(
///   routes: [...],
///   observers: [DevRevTransitionTrackingObserver()],
/// );
/// ```
class DevRevTransitionTrackingObserver extends NavigatorObserver {
  Future<void> _pauseRecordingForNavigation() =>
      DevRev.updateTransitioningState(true, isNavigation: true);

  /// Max wait for destination masks before falling back to resume.
  static const Duration _maskReadyTimeout = Duration(seconds: 1);
  Timer? _maskReadyTimer;

  /// Non-`TransitionRoute`s default to opaque (safer for custom routes).
  bool _isOpaque(Route<dynamic> route) =>
      route is! TransitionRoute || route.opaque;

  /// Resumes once [destination]'s masks are measured, or after
  /// [_maskReadyTimeout]; scoping stops a page dismissed on pop from satisfying
  /// the gate on the destination's behalf.
  void _resumeWhenMasksReady(
    VoidCallback action, {
    Route<dynamic>? destination,
  }) {
    _maskReadyTimer?.cancel();
    MaskController.instance.cancelNotifyWhenReady();

    void resume() {
      _maskReadyTimer?.cancel();
      _maskReadyTimer = null;
      MaskController.instance.cancelNotifyWhenReady();
      action();
    }

    _maskReadyTimer = Timer(_maskReadyTimeout, resume);
    MaskController.instance.notifyWhenReady(resume, destination: destination);
  }

  void _attachTransitionListener(
    Route<dynamic> route, {
    required bool isNavigation,
    Route<dynamic>? destination,
  }) {
    if (route is! TransitionRoute || route.animation == null) {
      // No animation to gate on — clear the pause scheduled by didPush/pop.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (isNavigation) {
          _resumeWhenMasksReady(
            () {
              DevRev.updateTransitioningState(false, isNavigation: true);
            },
            destination: destination,
          );
        } else {
          DevRev.updateTransitioningState(false);
        }
      });
      return;
    }
    final animation = route.animation!;
    // Page routes wait for destination masks; popups have no destination.
    final isPage = route is PageRoute;
    // Attaching mid-transition counts as started so the next terminal status
    // still resumes recording.
    var transitionStarted = animation.status == AnimationStatus.forward ||
        animation.status == AnimationStatus.reverse;
    animation.addStatusListener((status) {
      switch (status) {
        case AnimationStatus.forward:
        case AnimationStatus.reverse:
          transitionStarted = true;
          DevRev.updateTransitioningState(true, isNavigation: true);
          break;
        case AnimationStatus.completed:
          if (!transitionStarted) break;
          if (isPage) {
            _resumeWhenMasksReady(
              () {
                DevRev.updateTransitioningState(false, isNavigation: true);
              },
              destination: destination,
            );
          } else {
            DevRev.updateTransitioningState(false, isNavigation: true);
          }
          break;
        case AnimationStatus.dismissed:
          if (!transitionStarted) break;
          if (isPage) {
            _resumeWhenMasksReady(
              () {
                DevRev.updateTransitioningState(false, isNavigation: true);
              },
              destination: destination,
            );
          } else {
            DevRev.updateTransitioningState(false, isNavigation: true);
          }
          break;
      }
    });
    // Already terminal, so the listener above never fires.
    if (animation.status == AnimationStatus.completed ||
        animation.status == AnimationStatus.dismissed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (animation.status != AnimationStatus.completed &&
            animation.status != AnimationStatus.dismissed) {
          return;
        }
        if (isPage && isNavigation) {
          _resumeWhenMasksReady(
            () {
              DevRev.updateTransitioningState(false, isNavigation: true);
            },
            destination: destination,
          );
        } else {
          DevRev.updateTransitioningState(false);
        }
      });
    }
  }

  @override
  void didPush(Route route, Route? previousRoute) {
    final isNavigation = previousRoute != null;
    if (previousRoute != null) {
      MaskController.instance.setRouteCovered(previousRoute, _isOpaque(route));
      unawaited(_pauseRecordingForNavigation());
    }
    _attachTransitionListener(
      route,
      isNavigation: isNavigation,
      destination: route,
    );
    super.didPush(route, previousRoute);
  }

  @override
  void didPop(Route route, Route? previousRoute) {
    if (previousRoute != null) {
      MaskController.instance.setRouteCovered(previousRoute, false);
    }
    MaskController.instance.forgetRoute(route);
    unawaited(_pauseRecordingForNavigation());
    _attachTransitionListener(
      route,
      isNavigation: true,
      destination: previousRoute,
    );
    super.didPop(route, previousRoute);
  }

  @override
  void didRemove(Route route, Route? previousRoute) {
    if (previousRoute != null) {
      MaskController.instance.setRouteCovered(previousRoute, false);
    }
    MaskController.instance.forgetRoute(route);
    super.didRemove(route, previousRoute);
  }

  @override
  void didReplace({Route? newRoute, Route? oldRoute}) {
    if (oldRoute != null) MaskController.instance.forgetRoute(oldRoute);
    unawaited(_pauseRecordingForNavigation());
    if (newRoute != null) {
      _attachTransitionListener(
        newRoute,
        isNavigation: true,
        destination: newRoute,
      );
    }
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
  }
}
