package ai.devrev.sdk.bridge.flutter

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class DevRevSDKFlutterPlugin :
    FlutterPlugin,
    ActivityAware,
    MethodChannel.MethodCallHandler {
    companion object {
        private const val CHANNEL_NAME = "devrev_sdk_flutter"
    }

    private lateinit var channel: MethodChannel
    private lateinit var bridge: Bridge

    /**
     * Activity this plugin's engine is attached to, or null while detached.
     */
    private var attachedActivity: Activity? = null

    /**
     * Activity this process has most recently resumed, as observed since registration, or null when
     * the last one observed has paused.
     *
     * Attachment cannot answer whether [attachedActivity] is in front, since it happens during
     * onCreate; comparing the two is what does.
     */
    private var resumedActivity: Activity? = null

    /** Registered for the engine's lifetime, so resume and pause can be observed. */
    private var lifecycleCallbacks: Application.ActivityLifecycleCallbacks? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        val messenger: BinaryMessenger = binding.binaryMessenger
        channel = MethodChannel(messenger, CHANNEL_NAME)
        channel.setMethodCallHandler(this)

        val provider = MaskingProvider.getInstance()
        provider.addChannel(channel)

        // Registered here rather than on activity attach: attach arrives during onCreate, so
        // observing from engine attach is what gets this activity's first resume.
        observeActivityLifecycle(binding.applicationContext)

        val context: Context = binding.applicationContext
        bridge = Bridge(context).apply {
            setOnTransitionChangedListener { isTransitioning, isNavigation ->
                provider.changeTransitioningState(channel, isTransitioning, isNavigation)
            }
            setOnNavigationStartedListener {
                provider.onNavigationStarted()
            }
            setOnNavigationEndedListener {
                provider.onNavigationEnded()
            }
        }

        bridge.setMethodChannel(messenger)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            val method = Bridge.Method.methodMap[call.method]
            if (method != null) {
                bridge.handle(call, result)
            } else {
                result.notImplemented()
            }
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Method call error for ${call.method}: $e")
            result.error("METHOD_CALL_ERROR", "Failed to handle method ${call.method}", e.message)
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        try {
            stopObservingActivityLifecycle(binding.applicationContext)
            MaskingProvider.getInstance().removeChannel(channel)
            channel.setMethodCallHandler(null)
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error in onDetachedFromEngine: $e")
        }
    }

    // region - ActivityAware
    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        attachedActivity = binding.activity
        // Only if it is already in front: attach happens during onCreate, so an activity that never
        // comes forward would otherwise claim the foreground and never be corrected, since pause is
        // not delivered for an activity that was never resumed.
        if (isForeground(binding.activity)) {
            markActive()
        }
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        // Already inactive: this runs from onDestroy, after the activity's pause. Selection until
        // the reattached activity resumes comes from selectChannel's fallback.
        attachedActivity = null
    }

    override fun onDetachedFromActivity() {
        attachedActivity = null
        markInactive()
    }
    // endregion

    /**
     * Whether [activity] is in the foreground. Asks its own lifecycle first, since an engine
     * attached to an already-resumed activity sees no further resume.
     *
     * Two engines in one activity both read as foreground; activity identity cannot separate them.
     */
    private fun isForeground(activity: Activity): Boolean {
        val lifecycleState = (activity as? LifecycleOwner)?.lifecycle?.currentState
        if (lifecycleState != null) {
            return lifecycleState.isAtLeast(Lifecycle.State.RESUMED)
        }
        return activity === resumedActivity
    }

    /**
     * Observes which activity this process has in the foreground, for the engine's lifetime.
     *
     * Registered application-wide, so every activity's events arrive here and have to be matched
     * against [attachedActivity] to find this engine's own.
     */
    private fun observeActivityLifecycle(context: Context) {
        try {
            val application = context.applicationContext as? Application ?: return
            val callbacks = object : Application.ActivityLifecycleCallbacks {
                override fun onActivityResumed(resumed: Activity) {
                    resumedActivity = resumed
                    if (resumed === attachedActivity) {
                        markActive()
                    }
                }

                override fun onActivityPaused(paused: Activity) {
                    if (paused === resumedActivity) {
                        resumedActivity = null
                    }
                    if (paused === attachedActivity) {
                        markInactive()
                    }
                }

                override fun onActivityCreated(a: Activity, savedInstanceState: Bundle?) = Unit
                override fun onActivityStarted(a: Activity) = Unit
                override fun onActivityStopped(a: Activity) = Unit
                override fun onActivitySaveInstanceState(a: Activity, outState: Bundle) = Unit
                override fun onActivityDestroyed(a: Activity) = Unit
            }
            application.registerActivityLifecycleCallbacks(callbacks)
            lifecycleCallbacks = callbacks
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error observing activity lifecycle: $e")
        }
    }

    private fun stopObservingActivityLifecycle(context: Context) {
        try {
            val application = context.applicationContext as? Application
            lifecycleCallbacks?.let { application?.unregisterActivityLifecycleCallbacks(it) }
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error unregistering callbacks: $e")
        } finally {
            lifecycleCallbacks = null
            attachedActivity = null
            resumedActivity = null
        }
    }

    private fun markActive() {
        // Insurance only: the engine is always attached before any activity is.
        if (!::channel.isInitialized) return
        try {
            MaskingProvider.getInstance().setActiveChannel(channel)
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error marking active channel: $e")
        }
    }

    private fun markInactive() {
        if (!::channel.isInitialized) return
        try {
            MaskingProvider.getInstance().clearActiveChannel(channel)
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error clearing active channel: $e")
        }
    }
}
