package ai.devrev.sdk.bridge.flutter

import ai.devrev.sdk.DevRev
import ai.devrev.sdk.setInScreenTransitioning
import ai.devrev.sdk.setMaskLocationProvider
import android.content.res.Resources.getSystem
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.userexperior.bridge.model.MaskLocationProvider
import com.userexperior.bridge.model.SnapshotMask
import com.userexperior.bridge.model.SnapshotMaskCallback
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class MaskingProvider private constructor() : MaskLocationProvider {

    companion object {
        private const val TAG = "MaskingProvider"
        private const val LANDSCAPE_WIDTH_ADJUSTMENT_PX = 50
        private const val FETCH_TIMEOUT_MS = 200L
        private const val DESTINATION_MASK_TIMEOUT_MS = 300L

        /** Only fires when Dart is stuck, so it sits above the Dart-side pause bound. */
        private const val UNRESOLVED_MASK_TIMEOUT_MS = 1_500L

        @Volatile private var instance: MaskingProvider? = null

        fun getInstance(): MaskingProvider = instance ?: synchronized(this) {
            instance ?: MaskingProvider().also { instance = it }
        }

        /**
         * Picks the channel to ask for mask coordinates: [activeChannel] wins as the on-screen
         * engine, else the last entry, since no answer suppresses every frame.
         */
        internal fun selectChannel(
            activeChannel: MethodChannel?,
            allChannels: List<MethodChannel>,
        ): MethodChannel? = activeChannel ?: allChannels.lastOrNull()

        /**
         * Converts the coordinates Dart sent into device-pixel rects, shared by the per-frame
         * decision and the pre-capture re-read so the two cannot disagree about geometry.
         */
        private fun toMaskRects(locationsRaw: List<*>?, isLandscape: Boolean): Set<Rect> {
            locationsRaw ?: return emptySet()

            val rects = mutableSetOf<Rect>()
            for (locationRaw in locationsRaw) {
                val location = locationRaw as? Map<*, *> ?: continue
                val x = location["x"]?.toString()?.toDoubleOrNull() ?: continue
                val y = location["y"]?.toString()?.toDoubleOrNull() ?: continue
                val width = location["width"]?.toString()?.toDoubleOrNull() ?: continue
                val height = location["height"]?.toString()?.toDoubleOrNull() ?: continue

                if (width <= 0 || height <= 0) continue

                val left = x.roundToInt().coerceAtLeast(0)
                val top = y.roundToInt().coerceAtLeast(0)
                val right = (x + width).roundToInt().coerceAtLeast(left + 1) +
                    if (isLandscape) LANDSCAPE_WIDTH_ADJUSTMENT_PX else 0
                val bottom = (y + height).roundToInt().coerceAtLeast(top + 1)

                rects.add(Rect(left, top, right, bottom))
            }
            return rects
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val stateLock = Any()

    /** Registered channels in registration order; [setActiveChannel] moves the foreground one last. */
    private val channels = CopyOnWriteArrayList<MethodChannel>()

    /** Channel of the foreground engine, or null when no resumed activity has an engine attached. */
    private var activeChannel: MethodChannel? = null

    @Volatile private var isScreenTransitioning = false
    @Volatile private var awaitingDestinationMasks = false
    @Volatile private var navigationEndedAtMs = 0L

    /** When Dart first reported masks without bounds, or 0 when it is not currently doing so. */
    @Volatile private var unresolvedMasksSinceMs = 0L

    init {
        DevRev.setMaskLocationProvider(this)
    }

    fun addChannel(channel: MethodChannel) {
        synchronized(stateLock) {
            channels.add(channel)
        }
    }

    fun removeChannel(channel: MethodChannel) {
        synchronized(stateLock) {
            channels.remove(channel)
            if (activeChannel == channel) {
                activeChannel = null
            }
        }
    }

    /**
     * Marks [channel] foregrounded and moves it to the tail of [channels] so it stays the fallback
     * pick once [activeChannel] is cleared.
     */
    fun setActiveChannel(channel: MethodChannel) {
        synchronized(stateLock) {
            activeChannel = channel
            if (channels.remove(channel)) {
                channels.add(channel)
            }
        }
    }

    /** Clears [channel] as active, if it still is, when its activity leaves the foreground. */
    fun clearActiveChannel(channel: MethodChannel) {
        synchronized(stateLock) {
            if (activeChannel == channel) {
                activeChannel = null
            }
        }
    }

    fun changeTransitioningState(
        channel: MethodChannel,
        isTransitioning: Boolean,
        isNavigation: Boolean = false,
    ) {
        synchronized(stateLock) {
            when {
                isTransitioning -> {
                    isScreenTransitioning = true
                    awaitingDestinationMasks = false
                    navigationEndedAtMs = 0L
                    DevRev.setInScreenTransitioning(true)
                }
                isNavigation -> {
                    val wasAnimating = isScreenTransitioning
                    isScreenTransitioning = false
                    if (wasAnimating) {
                        awaitingDestinationMasks = true
                        navigationEndedAtMs = SystemClock.elapsedRealtime()
                    }
                    // Resume on nav end; frames stay suppressed via shouldSkip while awaiting masks.
                    DevRev.setInScreenTransitioning(false)
                }
                else -> {
                    isScreenTransitioning = false
                    awaitingDestinationMasks = false
                    navigationEndedAtMs = 0L
                    DevRev.setInScreenTransitioning(false)
                }
            }
        }
    }

    fun onNavigationStarted() {
        synchronized(stateLock) {
            isScreenTransitioning = true
            awaitingDestinationMasks = false
            navigationEndedAtMs = 0L
        }
        DevRev.setInScreenTransitioning(true)
    }

    fun onNavigationEnded() {
        synchronized(stateLock) {
            val wasAnimating = isScreenTransitioning
            isScreenTransitioning = false
            if (wasAnimating && !awaitingDestinationMasks) {
                awaitingDestinationMasks = true
                navigationEndedAtMs = SystemClock.elapsedRealtime()
            }
        }
        DevRev.setInScreenTransitioning(false)
    }

    override fun provideSnapshotMask(callback: SnapshotMaskCallback?) {
        callback ?: return

        // One lock acquisition so the channel and transition state describe the same instant.
        val channel: MethodChannel?
        val skipDuringAnimation: Boolean
        val awaitingAtFetchStart: Boolean
        synchronized(stateLock) {
            channel = selectChannel(activeChannel, channels)
            skipDuringAnimation = isScreenTransitioning && !awaitingDestinationMasks
            awaitingAtFetchStart = awaitingDestinationMasks
        }

        if (skipDuringAnimation || channel == null) {
            callback.onSnapshotMask(SnapshotMask(emptySet(), true))
            return
        }

        val latch = CountDownLatch(1)
        var snapshotMask = defaultSnapshotMask(awaitingAtFetchStart)

        mainHandler.post {
            channel.invokeMethod(
                "fetchFlutterData",
                null,
                object : MethodChannel.Result {
                    override fun success(result: Any?) {
                        snapshotMask = buildSnapshotMask(result)
                        latch.countDown()
                    }

                    override fun error(code: String, message: String?, details: Any?) {
                        snapshotMask = defaultSnapshotMask(awaitingAtFetchStart)
                        latch.countDown()
                    }

                    override fun notImplemented() {
                        snapshotMask = defaultSnapshotMask(awaitingAtFetchStart)
                        latch.countDown()
                    }
                },
            )
        }

        val completed = latch.await(FETCH_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        if (!completed) {
            Log.w(TAG, "provideSnapshotMask: fetch timed out after ${FETCH_TIMEOUT_MS}ms, skipping frame")
            clearAwaitingIfTimedOut()
            callback.onSnapshotMask(SnapshotMask(emptySet(), true))
            return
        }

        applyPostFetchState(snapshotMask)
        callback.onSnapshotMask(snapshotMask)
    }

    /**
     * Re-reads mask rects without touching per-frame state, for a caller about to sample Flutter's
     * pixels. Answers on the main thread, so callers chain their work from the callback. Returns
     * null (not an empty mask) on failure so "no rects" and "could not read" stay distinguishable.
     */
    override fun readMaskLocations(callback: SnapshotMaskCallback?) {
        callback ?: return

        val channel = synchronized(stateLock) { selectChannel(activeChannel, channels) }
        if (channel == null) {
            callback.onSnapshotMask(null)
            return
        }

        mainHandler.post {
            channel.invokeMethod(
                "fetchFlutterData",
                null,
                object : MethodChannel.Result {
                    override fun success(result: Any?) {
                        callback.onSnapshotMask(readOnlySnapshotMask(result))
                    }

                    override fun error(code: String, message: String?, details: Any?) {
                        callback.onSnapshotMask(null)
                    }

                    override fun notImplemented() {
                        callback.onSnapshotMask(null)
                    }
                },
            )
        }
    }

    /**
     * [buildSnapshotMask] cannot be reused: it advances timers owned by the once-per-frame call.
     * `shouldSkip` here means "do not trust these rects", not "drop the frame".
     */
    private fun readOnlySnapshotMask(result: Any?): SnapshotMask? {
        val payload = result as? Map<*, *> ?: return null
        val locationsRaw = payload["locations"] as? List<*> ?: return null
        val hasMasksRegistered = payload["hasMasksRegistered"] as? Boolean ?: false

        val displayMetrics = getSystem().displayMetrics
        val isLandscape = displayMetrics.widthPixels > displayMetrics.heightPixels
        val rects = toMaskRects(locationsRaw, isLandscape)

        // Painting only the measured masks leaves the rest bare, so keep the pass's own rects.
        if (hasMasksRegistered && rects.isEmpty()) {
            return SnapshotMask(emptySet(), true)
        }

        return SnapshotMask(rects, false)
    }

    private fun defaultSnapshotMask(awaitingDestination: Boolean): SnapshotMask =
        SnapshotMask(emptySet(), awaitingDestination)

    private fun buildSnapshotMask(result: Any?): SnapshotMask {
        val skipDueToAnimation = synchronized(stateLock) {
            isScreenTransitioning && !awaitingDestinationMasks
        }
        if (skipDueToAnimation) {
            return SnapshotMask(emptySet(), true)
        }

        val payload = result as? Map<*, *>
        val locationsRaw = payload?.get("locations") as? List<*>
        val fetchedHasMasksRegistered = payload?.get("hasMasksRegistered") as? Boolean ?: false
        val fetchedLocationCount = locationsRaw?.size ?: 0
        synchronized(stateLock) {
            markUnresolvedMasks(fetchedHasMasksRegistered && fetchedLocationCount == 0)
        }

        val displayMetrics = getSystem().displayMetrics
        val isLandscape = displayMetrics.widthPixels > displayMetrics.heightPixels
        val rects = toMaskRects(locationsRaw, isLandscape)

        val isEmpty = rects.isEmpty()
        val awaiting = awaitingDestinationMasks
        val destinationMaskTimeoutExpired = awaiting && isDestinationMaskTimeoutExpired()

        val shouldSkip = when {
            !isEmpty -> false
            // Masks arrived without bounds; time-bound the wait or a never-measured mask
            // suppresses every remaining frame.
            fetchedHasMasksRegistered -> !isUnresolvedMaskWaitExpired()
            awaiting && !destinationMaskTimeoutExpired -> true
            else -> false
        }

        return SnapshotMask(rects, shouldSkip)
    }

    private fun applyPostFetchState(snapshotMask: SnapshotMask) {
        synchronized(stateLock) {
            if (snapshotMask.locations.isNotEmpty()) {
                awaitingDestinationMasks = false
                navigationEndedAtMs = 0L
                return
            }
            clearAwaitingIfTimedOutLocked()
        }
    }

    private fun clearAwaitingIfTimedOut() {
        synchronized(stateLock) {
            clearAwaitingIfTimedOutLocked()
        }
    }

    private fun clearAwaitingIfTimedOutLocked() {
        if (awaitingDestinationMasks && isDestinationMaskTimeoutExpired()) {
            awaitingDestinationMasks = false
            navigationEndedAtMs = 0L
        }
    }

    private fun isDestinationMaskTimeoutExpired(): Boolean {
        val endedAt = navigationEndedAtMs
        if (endedAt == 0L) return false
        return SystemClock.elapsedRealtime() - endedAt >= DESTINATION_MASK_TIMEOUT_MS
    }

    /** Caller must hold [stateLock]. */
    private fun markUnresolvedMasks(unresolved: Boolean) {
        if (!unresolved) {
            unresolvedMasksSinceMs = 0L
            return
        }
        if (unresolvedMasksSinceMs == 0L) {
            unresolvedMasksSinceMs = SystemClock.elapsedRealtime()
        }
    }

    private fun isUnresolvedMaskWaitExpired(): Boolean {
        val since = synchronized(stateLock) { unresolvedMasksSinceMs }
        if (since == 0L) return false
        val expired = SystemClock.elapsedRealtime() - since >= UNRESOLVED_MASK_TIMEOUT_MS
        if (expired) {
            Log.w(
                TAG,
                "buildSnapshotMask: masks registered without bounds for " +
                    "${UNRESOLVED_MASK_TIMEOUT_MS}ms, resuming capture",
            )
        }
        return expired
    }
}
