import 'package:devrev_sdk_flutter/src/feature_configuration.dart';
import 'package:devrev_sdk_flutter/src/internal/devrev_sdk_method_channel.dart';
import 'package:devrev_sdk_flutter/src/internal/devrev_sdk_platform_interface.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockDevRevSDKFlutterPlatform
    with MockPlatformInterfaceMixin
    implements DevRevSDKPlatform {
  @override
  Future<void> addSessionProperties(Map<String, String> properties) async {}

  @override
  Future<void> clearSessionProperties() async {}

  @override
  Future<void> configure(
    String appID, [
    FeatureConfiguration? featureConfiguration,
  ]) async {}

  @override
  Future<void> updateFeatureConfiguration(
    FeatureConfiguration featureConfiguration,
  ) async {}

  @override
  Future<void> identifyAnonymousUser(String userID) async {}

  @override
  Future<void> identifyUnverifiedUser(
    String userID,
    String? organizationID,
  ) async {}

  @override
  Future<void> identifyVerifiedUser(String userID, String sessionToken) async {}

  @override
  Future<void> pauseRecording() async {}

  @override
  Future<void> processAllOnDemandSessions() async {}

  @override
  Future<void> resumeAllMonitoring() async {}

  @override
  Future<void> resumeRecording() async {}

  @override
  Future<void> showSupport({bool isAnimated = true}) async {}

  @override
  Future<void> startRecording() async {}

  @override
  Future<void> stopAllMonitoring() async {}

  @override
  Future<void> stopRecording() async {}

  @override
  Future<void> trackEvent(String name, Map<String, String> properties) async {}

  @override
  Future<void> trackScreenName(String screenName) async {}

  @override
  Future<bool?> get areOnDemandSessionsEnabled => throw UnimplementedError();

  @override
  Future<void> createSupportConversation() async {}

  @override
  Future<void> endTimer(String name, Map<String, String> properties) async {}

  @override
  Future<bool?> get isConfigured => throw UnimplementedError();

  @override
  Future<bool?> get isMonitoring => throw UnimplementedError();

  @override
  Future<bool?> get isRecording => throw UnimplementedError();

  @override
  Future<bool?> get isUserIdentified => throw UnimplementedError();

  @override
  Future<void> logout(String deviceID) async {}

  @override
  Future<void> processPushNotification(String payload) async {}

  @override
  Future<void> registerDeviceToken(String deviceToken, String deviceID) async {}

  @override
  Future<void> startTimer(String name, Map<String, String> properties) async {}

  @override
  Future<void> unregisterDevice(String deviceID) async {}

  @override
  Future<void> updateTransitioningState(bool state) async {}

  @override
  Future<void> updateUser(Map<String, dynamic> identity) async {}

  @override
  Future<void> setInAppLinkHandler([
    void Function(String url)? handler,
  ]) async {}

  @override
  Future<void> setInScreenTransitioning(bool value) async {}

  @override
  Future<void> setPrefersSystemTheme(bool value) async {}

  @override
  Future<void> setShouldDismissModalsOnOpenLink(bool value) async {}

  @override
  Future<void> pauseUserInteractionTracking() async {}

  @override
  Future<void> resumeUserInteractionTracking() async {}

  @override
  Future<void> captureError(
    String error,
    String? stackTrace,
    String tag,
  ) async {}
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final DevRevSDKPlatform initialPlatform = DevRevSDKPlatform.instance;

  test('$MethodChannelDevRevSDK is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelDevRevSDK>());
  });
}
