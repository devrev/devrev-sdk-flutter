desc "Configuration"
 class Configuration
     INTERMEDIATE_PATH = ".build"
     OUTPUT_PATH = "#{INTERMEDIATE_PATH}/Publish"

     GIT_ORGANIZATION = "devrev"

     PUBLIC_REPOSITORY_BASE = "devrev-sdk-flutter"
     PUBLIC_REPOSITORY = "#{GIT_ORGANIZATION}/#{PUBLIC_REPOSITORY_BASE}"

     TEST_REPOSITORY_BASE = "flutter-sdk-test"
     TEST_REPOSITORY = "#{GIT_ORGANIZATION}/#{TEST_REPOSITORY_BASE}"

     SAMPLE_PATH = "example"
     TEMPLATES_PATH = "Templates"

     SAMPLE_CONFIG_TEMPLATES = {
         "pubspec.yaml" => "pubspec.yaml.erb"
     }

     PRE_RELEASE_CONFIG_TEMPLATES = {
         "example/pubspec.yaml" => "pubspec_git.yaml.erb"
     }
 end
