<!--
    Guidelines:
    1. Make sure the PR title is descriptive and *NOT* the auto-generated one
    from the branch name, using the format:
     TICKET: Descriptive title
    2. Add the relevant reviewers manually.
    3. Delete any optional sections that are not relevant.
 -->

## Description :pencil2:
<!--
    (Required) A brief description of the changes this PR introduces.
    If the PR requires documentation update, please link the related PR in the Links section.
-->

- [ ] Requires documentation update
- [ ] Requires manual QA

<!-- General reviewing notes. -->
> [!IMPORTANT]
> **Check** the ***Hide whitespace*** option when reviewing.

## Links :round_pushpin:
<!--
    (Required) Links to related tickets, PRs and documentation pages. Tickets (e.g. `ISS-XXXXX`, `TKT-XXXXX`) and Github references are
    automatically linked.
-->
/close ISS-

## AI-assisted work :chart_with_upwards_trend:
<!--
    (Optional) State what percentage of this PR was completed using AI tools.
-->
%

## Testing Instructions :test_tube:
<!--
    (Optional) Please describe in detail how you tested your changes.
    Include details of your testing environment, and the tests you ran to see
    how your change affects other areas of the code, etc.
    If the PR requires manual QA, please describe the steps to be taken to test the PR.
-->
