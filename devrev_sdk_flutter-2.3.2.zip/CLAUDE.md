# CLAUDE.md

This document defines rules and constraints for AI-generated code in the DevRev Flutter SDK. This is a production plugin consumed by external Flutter applications. It bridges Dart to native Android (Kotlin) and iOS (Swift) via Flutter's Method Channel. Stability, backward compatibility, and minimal footprint are top priorities.

All rules are mandatory. Any violation results in invalid output.

---

## 1. AI Execution Workflow (MANDATORY)

Before generating any code, you must:

1. Identify which layer is affected: Dart public API (lib/), Dart internals (lib/src/internal/), iOS bridge (ios/), Android bridge (android/), example app (example/), or tooling (tool/)
2. Determine whether the change affects the public API surface
3. Validate backward compatibility
4. Determine if the change requires updates across multiple layers (e.g., a new method requires changes in the Dart API, the method channel implementation, the method enum, AND both native bridges)
5. Identify platform-specific behavior differences (e.g., pixel ratio scaling, landscape adjustments)
6. Define test coverage

If any of the above is unclear:

**STOP and ask for clarification. Do not guess architecture or behavior.**

---

## 2. Repository Structure

    devrev_sdk_flutter/
    ├── android/                  Native Android (Kotlin) bridge
    ├── ios/                      Native iOS (Swift) bridge
    ├── lib/                      Dart public API + platform interface
    │   ├── devrev.dart                   Public static API
    │   ├── devrev_mask.dart              DevRevMask / DevRevUnmask widgets
    │   ├── devrev_monitored_app.dart     DevRevMonitoredApp + GoRouter observer
    │   └── src/internal/                 Implementation details (not re-exported)
    │       ├── devrev_sdk_platform_interface.dart
    │       ├── devrev_sdk_method_channel.dart
    │       ├── devrev_sdk_method.dart
    │       ├── mask_controller.dart
    │       ├── mask_location.dart
    │       ├── mask_global_key.dart
    │       └── sdk_version_generated.dart
    ├── example/                  Full sample app
    ├── test/                     Unit + method channel tests
    ├── tool/                     SDK version sync utility
    ├── fastlane/                 iOS/Android CI/CD automation
    ├── .github/workflows/        GitHub Actions for pub.dev publishing
    ├── .circleci/                Multi-stage release pipeline
    ├── pubspec.yaml              Plugin manifest
    ├── analysis_options.yaml     Lint config (extends flutter_lints)
    ├── CHANGELOG.md              Version history
    ├── CONTRIBUTING.md           Dev setup + release workflow
    └── MIGRATION.md              UserExperior to DevRev migration guide

---

## 3. Architecture

    DevRev (public static API — all static methods)
      └── DevRevSDKPlatform (abstract interface)
            └── MethodChannelDevRevSDK (concrete implementation)
                  └── MethodChannel('devrev_sdk_flutter')
                        ├── Android native (Kotlin)
                        └── iOS native (Swift)

Bidirectional communication: native calls back into Dart via fetchFlutterData (mask coordinates) and inAppLinkReceived (URL events).

---

## 4. Layer Responsibilities (STRICT)

### lib/*.dart — Public API Surface

- Top-level Dart files are the public API consumed by application developers
- DevRev class: All SDK calls as static methods (configure, identify, record, track, support, push)
- DevRevMask / DevRevUnmask: Widgets for sensitive UI masking in recordings
- DevRevMonitoredApp: Drop-in MaterialApp replacement with auto screen-transition tracking
- DevRevTransitionTrackingObserver: NavigatorObserver for GoRouter integration
- Nothing from lib/src/internal/ should be re-exported or directly importable by consumers

### lib/src/internal/ — Implementation Details

- DevRevSDKPlatform: Abstract platform contract with UnimplementedError stubs
- MethodChannelDevRevSDK: Concrete method channel implementation — all native calls route through a single _invokeMethod wrapper
- DevRevSDKMethod: Enum of all method channel method names
- MaskController: Singleton registry of mask/unmask coordinates polled by native layer
- sdk_version_generated.dart: Auto-generated version constant — never edit manually

### ios/ — iOS Native Bridge (Swift)

- Receives method channel calls and delegates to the native DevRev iOS SDK
- Mask coordinates use 1.0 pixel ratio (scaling handled natively)

### android/ — Android Native Bridge (Kotlin)

- Receives method channel calls and delegates to the native DevRev Android SDK
- Mask coordinates are multiplied by device pixel ratio
- Landscape orientation applies a hardcoded +50px width adjustment to masks

### example/ — Sample App

- Reference implementation demonstrating all SDK features
- Has its own dependencies (firebase_messaging, webview_flutter, shared_preferences, flutter_secure_storage, uuid) that are not part of the plugin itself
- Changes here do not affect the library

### tool/ — Build Utilities

- update_sdk_version.dart: Reads version from pubspec.yaml, writes to sdk_version_generated.dart
- Must be run before releases

Do not mix responsibilities across layers.

---

## 5. Public API Rules (CRITICAL)

- The DevRev class with its static methods is the primary public API surface
- DevRevMask, DevRevUnmask, DevRevMonitoredApp, and DevRevTransitionTrackingObserver are public widgets/classes
- Public APIs must remain backward compatible at all times
- Do not change existing method signatures unless explicitly instructed
- Do not remove or rename public methods, classes, or widgets
- Deprecated methods must remain in place and delegate to their replacements — never hard-delete them
- Do not expose anything from lib/src/internal/ to consumers
- DevRev._isConfigured is the source of truth for configuration state — the platform channel isConfigured getter is unreliable; do not change this pattern without explicit instruction

If a change breaks backward compatibility:

**Output is invalid.**

---

## 6. Adding New Methods (MANDATORY SEQUENCE)

Every new SDK method must follow this exact sequence:

1. **Add to DevRevSDKMethod enum** in lib/src/internal/devrev_sdk_method.dart
2. **Add to DevRevSDKPlatform** abstract interface in lib/src/internal/devrev_sdk_platform_interface.dart with an UnimplementedError stub
3. **Implement in MethodChannelDevRevSDK** in lib/src/internal/devrev_sdk_method_channel.dart using the _invokeMethod wrapper
4. **Add public static method to DevRev class** in lib/devrev.dart
5. **Implement in iOS native bridge** (ios/)
6. **Implement in Android native bridge** (android/)
7. **Add tests** for the new method

Skipping any step results in invalid output.

---

## 7. Error Handling Pattern (MANDATORY)

All method channel calls must route through the single _invokeMethod wrapper in MethodChannelDevRevSDK:

    Future<T?> _invokeMethod<T>(DevRevSDKMethod method, [Map<String, dynamic>? arguments]) async {
      try {
        return await methodChannel.invokeMethod<T>(method.value, arguments);
      } catch (e) {
        debugPrint('DevRev method ${method.value} error: $e');
        return null;
      }
    }

Do not call methodChannel.invokeMethod directly. Do not throw exceptions from public API methods — return null on failure with a debugPrint. All platform methods return Future of nullable type.

---

## 8. Dependency Rules

- The plugin must have minimal production dependencies — only flutter SDK and plugin_platform_interface
- Do not introduce new Dart package dependencies without explicit justification
- Do not introduce new native dependencies without explicit justification
- Example app dependencies (firebase_messaging, webview_flutter, etc.) are scoped to example/ only and must never leak into the plugin itself
- Prefer existing patterns and libraries already in the project

---

## 9. Dart Code Style (STRICT)

- Lint config extends package:flutter_lints/flutter.yaml — all lint rules must pass
- Files: snake_case.dart
- Public classes: PascalCase (DevRevMask, MaskController)
- Private classes: _PascalCase (_BaseMaskWidget, _BaseMaskState)
- Methods and variables: camelCase (identifyUnverifiedUser)
- Private fields: _camelCase (_masks, _debounceTimer)
- Enums: PascalCase type, camelCase values (DevRevSDKMethod.configure)
- One class per file (generally)
- Public API in top-level lib/*.dart files only
- All implementation details under lib/src/internal/ — never re-exported
- Abstract base classes for widgets are private
- Prefer final and const where possible
- No unused imports
- No commented-out code
- No TODO comments
- No magic numbers without explanation

---

## 10. Swift (iOS) Code Style

- PascalCase for types and classes, camelCase for methods and properties
- Do not force-unwrap optionals — handle nil safely
- Do not log sensitive or PII data
- Mask coordinates use 1.0 pixel ratio — do not apply device pixel ratio scaling on iOS

---

## 11. Kotlin (Android) Code Style

- Kotlin only — do not introduce Java files
- No !! operator — use safe calls and explicit null handling
- Prefer val over var
- Use immutable data structures where possible
- Mask coordinates must be multiplied by device pixel ratio
- Landscape orientation requires +50px width adjustment on masks

---

## 12. Design Patterns (RESPECT EXISTING)

These patterns are established in the codebase. Follow them for all new code:

- **Singleton:** MaskController.instance (private constructor + static final)
- **Abstract Platform Interface:** DevRevSDKPlatform with UnimplementedError stubs for all methods
- **Mixin:** WidgetsBindingObserver on state classes for lifecycle management
- **Debounce:** Timer-based debounce (200ms) for mask position updates
- **Null-safe futures:** All platform methods return Future of nullable type — failures return null + debugPrint
- **State deduplication:** isTransitioningState guard prevents redundant native calls
- **Local flag override:** DevRev._isConfigured bypasses unreliable platform getter

---

## 13. Generated Files (NEVER EDIT MANUALLY)

- lib/src/internal/sdk_version_generated.dart is auto-generated
- To regenerate, run: dart run tool/update_sdk_version.dart
- This must be run before any release after updating the version in pubspec.yaml

---

## 14. Platform-Specific Behavior (CRITICAL)

Be aware of these differences when modifying mask or coordinate-related code:

- **Android:** Mask coordinates are multiplied by device pixel ratio. Landscape orientation adds a hardcoded +50px width adjustment.
- **iOS:** Mask coordinates use 1.0 pixel ratio — scaling is handled natively. No landscape adjustment.

Do not unify these behaviors without explicit instruction. They exist because of fundamental platform differences.

---

## 15. Widget Integration Notes

- **DevRevMonitoredApp:** Drop-in MaterialApp replacement. Handles screen transition tracking automatically.
- **DevRevTransitionTrackingObserver:** Must be used directly by GoRouter users instead of DevRevMonitoredApp.
- **DevRevMask / DevRevUnmask:** Use MaskGlobalKey (UUID-tagged GlobalKey) for bounds tracking. Position updates are debounced at 200ms via MaskController.

---

## 16. Key Build and Validation Commands

    flutter analyze         # Static analysis — must pass with zero issues
    dart format .           # Code formatting — must produce no changes
    flutter test            # Unit and method channel tests
    dart run tool/update_sdk_version.dart   # Regenerate version constant

---

## 17. Testing Requirements (MANDATORY)

All new logic must include tests.

### Requirements

- Mock platform via MockPlatformInterfaceMixin
- Test method channel bindings for any new methods
- Validate behavior, not implementation details
- Include edge cases and failure scenarios
- Unit tests live in test/
- Integration tests live in example/integration_test/

If tests are missing for new logic:

**Output is invalid.**

---

## 18. Commit Style

- Commit messages must be a **single line** written in **sentence case**
- Do not use Conventional Commits prefixes (no feat:, fix:, chore:, etc.)
- The message should be a clear, concise description of the change

Correct examples:

    Add support for captureError method
    Fix mask coordinate calculation in landscape mode

Incorrect examples:

    feat: add support for captureError method
    Added support for captureError method.

---

## 19. Pull Request Guidelines

When raising a pull request, always follow the template defined in .github/pull_request_template.md if one exists. Read the file and populate every section it defines. Do not omit or skip sections.

---

## 20. Release Checklist

Before releasing a new version:

1. Update version in pubspec.yaml
2. Update CHANGELOG.md with the new version entry
3. Run dart run tool/update_sdk_version.dart to regenerate sdk_version_generated.dart
4. Ensure flutter analyze passes with zero issues
5. Ensure dart format . produces no changes
6. Ensure flutter test passes
7. iOS deployment target must be set to 15.0 in the example app's Xcode project

---

## 21. Forbidden Patterns

Never generate:

- TODO comments
- Placeholder or stub implementations in production code
- Fake or mock logic outside of test files
- Magic numbers without a named constant or explanatory comment
- Unused imports
- Commented-out code
- Force-unwrapped optionals (!! in Kotlin, force unwrap in Swift)
- Breaking changes to the public API
- Direct methodChannel.invokeMethod calls bypassing _invokeMethod wrapper
- Direct imports from lib/src/internal/ in consumer-facing documentation or examples
- Manual edits to sdk_version_generated.dart
- New Dart package dependencies without explicit approval

If any are present:

**Output is invalid.**

---

## 22. Self-Review (MANDATORY)

After generating any code, you must verify:

1. No public API breakage
2. Method enum updated if a new method was added
3. Platform interface updated with UnimplementedError stub
4. Method channel implementation uses _invokeMethod wrapper
5. Both native bridges (iOS and Android) updated if a new method was added
6. Platform-specific coordinate/scaling behavior preserved correctly
7. Code style compliance for all languages involved
8. No forbidden patterns present
9. Test coverage provided
10. sdk_version_generated.dart not manually edited

Fix all issues before final output.

---

## 23. Definition of Production-Ready Code

Code is production-ready only if it is:

- Backward compatible
- Fully implemented across all required layers (Dart, iOS, Android)
- Following established design patterns (singleton, platform interface, null-safe futures)
- Secure — no PII in logs, no exposed internals
- Tested
- Compliant with all style rules and lint checks
- Free of all forbidden patterns

---

## 24. Version Control Rules

Do not perform git operations (commit, push, merge, rebase, tag) without explicit instruction.