package ai.devrev.sdk.bridge.flutter

import ai.devrev.sdk.model.FeatureConfiguration
import ai.devrev.sdk.model.SupportWidgetTheme

/**
 * Parser for converting Flutter method call arguments to native FeatureConfiguration objects.
 */
object FeatureConfigurationParser {
    /**
     * Parses a FeatureConfiguration from a map of arguments.
     *
     * @param map The map containing the feature configuration data.
     * @return A FeatureConfiguration object, or null if the map is null or empty.
     */
    fun parseFeatureConfiguration(map: Map<String, Any?>?): FeatureConfiguration? {
        if (map == null || map.isEmpty()) {
            return null
        }

        val enableFrameCapture = map["enableFrameCapture"] as? Boolean ?: true
        val autoStartRecording = map["autoStartRecording"] as? Boolean ?: true
        val prefersDialogMode = map["prefersDialogMode"] as? Boolean ?: false
        val alwaysUseRemoteConfig = map["alwaysUseRemoteConfig"] as? Boolean ?: true

        val supportWidgetThemeMap = map["supportWidgetTheme"] as? Map<String, Any?>
        val supportWidgetTheme = SupportWidgetThemeParser.parseSupportWidgetTheme(supportWidgetThemeMap)
            ?: return null

        return FeatureConfiguration(
            enableFrameCapture = enableFrameCapture,
            autoStartRecording = autoStartRecording,
            prefersDialogMode = prefersDialogMode,
            alwaysUseRemoteConfig = alwaysUseRemoteConfig,
            supportWidgetTheme = supportWidgetTheme
        )
    }
}

object SupportWidgetThemeParser {
    /**
     * Parses a SupportWidgetTheme from a map of arguments.
     *
     * @param map The map containing the support widget theme data.
     * @return A SupportWidgetTheme object, or null if the map is null or empty.
     */
    fun parseSupportWidgetTheme(map: Map<String, Any?>?): SupportWidgetTheme? {
        if (map == null || map.isEmpty()) {
            return null
        }

        val prefersSystemTheme = map["prefersSystemTheme"] as? Boolean ?: true
        val primaryTextColor = map["primaryTextColor"] as? String
        val accentColor = map["accentColor"] as? String

        val spacingMap = map["spacing"] as? Map<*, *>
        val spacing = if (spacingMap != null) {
            spacingMap.entries.associate { (it.key as? String ?: "") to (it.value as? String ?: "") }
                .filterKeys { it.isNotEmpty() }
        } else {
            null
        }

        return SupportWidgetTheme(
            prefersSystemTheme = prefersSystemTheme,
            primaryTextColor = primaryTextColor,
            accentColor = accentColor,
            spacing = spacing
        )
    }
}
