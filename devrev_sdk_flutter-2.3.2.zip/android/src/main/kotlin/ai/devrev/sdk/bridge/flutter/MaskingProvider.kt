package ai.devrev.sdk.bridge.flutter

import ai.devrev.sdk.DevRev
import ai.devrev.sdk.setMaskLocationProvider
import com.userexperior.bridge.model.MaskLocationProvider
import com.userexperior.bridge.model.SnapshotMask
import com.userexperior.bridge.model.SnapshotMaskCallback
import android.os.Handler
import android.os.Looper
import android.util.Log
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.atomic.AtomicBoolean
import android.graphics.Rect
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.roundToInt

class MaskingProvider private constructor() : MaskLocationProvider {
    private val channels = CopyOnWriteArrayList<MethodChannel>()
    private val transitioningChannels = ConcurrentHashMap.newKeySet<MethodChannel>()
    private val isProcessing = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())

    @Volatile
    private var cachedSnapshotMask: SnapshotMask = SnapshotMask(emptySet(), false)

    private val pendingRefreshCallbacks = ArrayList<SnapshotMaskCallback>()

    private val pendingRefreshLock = Any()

    companion object {

        /**
         * The maximum duration in milliseconds to wait for the Flutter side to respond
         * with masking location data before the watchdog timer forces a finalization
         * of the update cycle.
         */
        private const val WATCHDOG_MS = 200L

        /** If [finalizeUpdate] never runs, callbacks could accumulate; drop oldest beyond this cap. */
        private const val MAX_PENDING_REFRESH_CALLBACKS = 64

        @Volatile
        private var instance: MaskingProvider? = null

        fun getInstance(): MaskingProvider {
            return instance ?: synchronized(this) {
                instance ?: MaskingProvider().also {
                    instance = it
                    DevRev.setMaskLocationProvider(it)
                }
            }
        }
    }

    fun addChannel(channel: MethodChannel) {
        if (!channels.contains(channel)) {
            channels.add(channel)
        }
    }

    fun removeChannel(channel: MethodChannel) {
        channels.remove(channel)
        transitioningChannels.remove(channel)
    }

    fun changeTransitioningState(channel: MethodChannel, state: Boolean) {
        if (state) {
            transitioningChannels.add(channel)
        } else {
            transitioningChannels.remove(channel)
            runOnMain { beginFlutterMaskFetchCycleIfIdle() }
        }
    }

    override fun provideSnapshotMask(callback: SnapshotMaskCallback?) {
        if (callback == null) return

        beginFlutterMaskFetchCycleIfIdle()

        callback.onSnapshotMask(maskForCaller())
        if (isProcessing.get()) {
            synchronized(pendingRefreshLock) {
                var dropped = 0
                while (pendingRefreshCallbacks.size >= MAX_PENDING_REFRESH_CALLBACKS) {
                    pendingRefreshCallbacks.removeAt(0)
                    dropped++
                }
                if (dropped > 0) {
                    Log.w(
                        "MaskingProvider",
                        "pendingRefreshCallbacks exceeded $MAX_PENDING_REFRESH_CALLBACKS (finalizeUpdate stuck?); dropped $dropped oldest",
                    )
                }
                pendingRefreshCallbacks.add(callback)
            }
        }
    }

    private fun beginFlutterMaskFetchCycleIfIdle() {
        val activeChannels = channels.toList()
        if (activeChannels.isEmpty() || !isProcessing.compareAndSet(false, true)) return

        val allLocations = ConcurrentHashMap.newKeySet<Rect>()
        val remaining = AtomicInteger(activeChannels.size)
        val cycleDone = AtomicBoolean(false)

        val watchdog = Runnable {
            if (cycleDone.compareAndSet(false, true)) {
                finalizeUpdate(allLocations)
            }
        }
        handler.postDelayed(watchdog, WATCHDOG_MS)

        runOnMain {
            for (channel in activeChannels) {
                try {
                    channel.invokeMethod("fetchFlutterData", null, object : MethodChannel.Result {
                        override fun success(result: Any?) {
                            try {
                                val payload = (result as? Map<String, Any>) ?: emptyMap()
                                (payload["locations"] as? List<Map<String, String>>)
                                    ?.forEach { map ->
                                        map.toRect()?.let { allLocations.add(it) }
                                    }
                            } catch (e: Exception) {
                                Log.e("MaskingProvider", "Error processing locations: $e")
                            } finally {
                                if (remaining.decrementAndGet() == 0) {
                                    if (cycleDone.compareAndSet(false, true)) {
                                        handler.removeCallbacks(watchdog)
                                        finalizeUpdate(allLocations)
                                    }
                                }
                            }
                        }

                        override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                            if (remaining.decrementAndGet() == 0) {
                                if (cycleDone.compareAndSet(false, true)) {
                                    handler.removeCallbacks(watchdog)
                                    finalizeUpdate(allLocations)
                                }
                            }
                        }

                        override fun notImplemented() {
                            if (remaining.decrementAndGet() == 0) {
                                if (cycleDone.compareAndSet(false, true)) {
                                    handler.removeCallbacks(watchdog)
                                    finalizeUpdate(allLocations)
                                }
                            }
                        }
                    })
                } catch (e: Exception) {
                    if (remaining.decrementAndGet() == 0) {
                        if (cycleDone.compareAndSet(false, true)) {
                            handler.removeCallbacks(watchdog)
                            finalizeUpdate(allLocations)
                        }
                    }
                }
            }
        }
    }

    private fun runOnMain(block: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block.run()
        } else {
            handler.post(block)
        }
    }

    private fun maskForCaller(): SnapshotMask =
        if (cachedSnapshotMask.locations.isNotEmpty()) cachedSnapshotMask
        else SnapshotMask(emptySet(), false)

    private fun finalizeUpdate(locations: Set<Rect>) {
        // Recording uses DevRev.setInScreenTransitioning; never skip applying mask rects here.
        val allChannelsInTransition =
            channels.isNotEmpty() && transitioningChannels.size == channels.size
        val effectiveLocations =
            when {
                locations.isNotEmpty() -> locations
                allChannelsInTransition && cachedSnapshotMask.locations.isNotEmpty() ->
                    HashSet(cachedSnapshotMask.locations)
                else -> locations
            }
        val freshMask = SnapshotMask(effectiveLocations, false)
        cachedSnapshotMask = freshMask
        isProcessing.set(false)
        val asyncCallbacks =
            synchronized(pendingRefreshLock) {
                val copy = ArrayList(pendingRefreshCallbacks)
                pendingRefreshCallbacks.clear()
                copy
            }
        if (asyncCallbacks.isEmpty()) return
        runOnMain {
            for (cb in asyncCallbacks) {
                try {
                    cb.onSnapshotMask(freshMask)
                } catch (e: Exception) {
                    Log.e("MaskingProvider", "onSnapshotMask after fetch: $e")
                }
            }
        }
    }

    private fun Map<String, String>.toRect(): Rect? {
        val x = this["x"]?.toFloatOrNull() ?: return null
        val y = this["y"]?.toFloatOrNull() ?: return null
        val width = this["width"]?.toFloatOrNull() ?: return null
        val height = this["height"]?.toFloatOrNull() ?: return null

        if (width <= 0 || height <= 0) return null

        // Flutter sends physical px as decimals; round (not truncate) so masks stay aligned with sub-pixel layout.
        // Clamp origin to >= 0 for on-screen coordinates; enforce right > left and bottom > top so Rect is never empty.
        val left = x.roundToInt().coerceAtLeast(0)
        val top = y.roundToInt().coerceAtLeast(0)
        val right = (x + width).roundToInt().coerceAtLeast(left + 1)
        val bottom = (y + height).roundToInt().coerceAtLeast(top + 1)
        return Rect(left, top, right, bottom)
    }
}
