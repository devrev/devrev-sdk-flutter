package ai.devrev.sdk.bridge.flutter

import ai.devrev.sdk.model.Identity
import ai.devrev.sdk.model.UserInfo
import ai.devrev.sdk.model.OrganizationInfo
import ai.devrev.sdk.model.AccountInfo

object IdentityParser {
  fun parseIdentity(map: Map<String, Any?>): Identity {
    return Identity(
      userId = map["userRef"] as? String ?: "",
      organizationId = map["organizationRef"] as? String,
      accountId = map["accountRef"] as? String,
      userInfo = map.getSafeMap("userTraits")?.let { parseUserTraits(it) },
      organizationInfo = map.getSafeMap("organizationTraits")?.let { parseOrganizationTraits(it) },
      accountInfo = map.getSafeMap("accountTraits")?.let { parseAccountTraits(it) }
    )
  }

  private fun parseUserTraits(map: Map<String, Any?>) = UserInfo(
    displayName = map["displayName"] as? String,
    email = map["email"] as? String,
    fullName = map["fullName"] as? String,
    description = map["description"] as? String,
    phoneNumbers = map.getSafeStringList("phoneNumbers"),
    customFields = map.getSafeMap("customFields")?.toAnyMap()
  )

  private fun parseOrganizationTraits(map: Map<String, Any?>) = OrganizationInfo(
    displayName = map["displayName"] as? String,
    domain = map["domain"] as? String,
    description = map["description"] as? String,
    phoneNumbers = map.getSafeStringList("phoneNumbers"),
    tier = map["tier"] as? String,
    customFields = map.getSafeMap("customFields")?.toAnyMap()
  )

  private fun parseAccountTraits(map: Map<String, Any?>) = AccountInfo(
    displayName = map["displayName"] as? String,
    domains = map.getSafeStringList("domains"),
    description = map["description"] as? String,
    phoneNumbers = map.getSafeStringList("phoneNumbers"),
    websites = map.getSafeStringList("websites"),
    tier = map["tier"] as? String,
    customFields = map.getSafeMap("customFields")?.toAnyMap()
  )

  private fun Map<String, Any?>.getSafeMap(key: String): Map<String, Any?>? {
    val value = this[key]
    if (value is Map<*, *> && value.keys.all { it is String }) {
      return value.entries.associate { (it.key as String) to it.value }
    }
    return null
  }

  private fun Map<String, Any?>.getSafeStringList(key: String): List<String>? {
    val list = this[key]
    return (list as? List<*>)?.mapNotNull { it as? String }
  }

  private fun Map<String, Any?>.toAnyMap(): Map<String, Any>? {
    val result = mutableMapOf<String, Any>()

    for ((key, value) in this) {
      when (value) {
        is String, is Number, is Boolean -> result[key] = value
        is Map<*, *> -> {
          if (value.keys.all { it is String }) {
            val nestedMap = (value.entries.associate {
              (it.key as String) to it.value
            } as Map<String, Any?>).toAnyMap()
            if (nestedMap != null) result[key] = nestedMap
          }
        }
      }
    }

    return result.takeIf { it.isNotEmpty() }
  }
}
