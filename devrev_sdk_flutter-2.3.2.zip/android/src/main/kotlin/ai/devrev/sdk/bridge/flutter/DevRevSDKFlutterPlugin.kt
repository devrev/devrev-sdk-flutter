package ai.devrev.sdk.bridge.flutter

import android.content.Context
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class DevRevSDKFlutterPlugin : FlutterPlugin, MethodChannel.MethodCallHandler {
    companion object {
        private const val CHANNEL_NAME = "devrev_sdk_flutter"
    }

    private lateinit var channel: MethodChannel
    private lateinit var bridge: Bridge

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        val messenger: BinaryMessenger = binding.binaryMessenger
        channel = MethodChannel(messenger, CHANNEL_NAME)
        channel.setMethodCallHandler(this)

        val provider = MaskingProvider.getInstance()
        provider.addChannel(channel)

        val context: Context = binding.applicationContext
        bridge = Bridge(context).apply {
            setOnTransitionChangedListener { isTransitioning ->
                provider.changeTransitioningState(channel, isTransitioning)
            }
        }

        bridge.setMethodChannel(messenger)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            val method = Bridge.Method.methodMap[call.method]
            if (method != null) {
                bridge.handle(call, result)
            } else {
                result.notImplemented()
            }
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Method call error for ${call.method}: $e")
            result.error("METHOD_CALL_ERROR", "Failed to handle method ${call.method}", e.message)
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        try {
            MaskingProvider.getInstance().removeChannel(channel)
            channel.setMethodCallHandler(null)
        } catch (e: Exception) {
            android.util.Log.e("DevRevSDKFlutterPlugin", "Error in onDetachedFromEngine: $e")
        }
    }
}
