package ai.devrev.sdk.bridge.flutter

import ai.devrev.sdk.*
import ai.devrev.sdk.model.FeatureConfiguration
import ai.devrev.sdk.model.Identity
import android.content.Context
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import android.util.Log

/**
 * Bridge class that handles communication between Flutter and the native DevRev SDK.
 *
 * This class implements the platform-specific logic for the DevRev SDK Flutter plugin.
 * It processes method calls from Flutter and translates them into appropriate native SDK calls.
 *
 * @property context The Android application context needed for SDK initialization.
 */
class Bridge(private val context: Context) {
	private var onTransitionChangedListener: ((Boolean) -> Unit)? = null
	private var inAppLinkHandler: ((String) -> Unit)? = null
	private lateinit var methodChannel: MethodChannel

	fun setMethodChannel(messenger: io.flutter.plugin.common.BinaryMessenger) {
		methodChannel = MethodChannel(messenger, "devrev_sdk_flutter")
	}

	fun setOnTransitionChangedListener(listener: (Boolean) -> Unit) {
		onTransitionChangedListener = listener
	}

	/*
	 * An enum representing the methods supported by the DevRev SDK.
	 * Each method corresponds to a specific SDK operation.
	 */
	enum class Method(val methodName: String) {
		CONFIGURE("configure"),
		UPDATE_FEATURE_CONFIGURATION("updateFeatureConfiguration"),
		SHOW_SUPPORT("showSupport"),
		CREATE_SUPPORT_CONVERSATION("createSupportConversation"),
		IDENTIFY_ANONYMOUS_USER("identifyAnonymousUser"),
		IDENTIFY_UNVERIFIED_USER("identifyUnverifiedUser"),
		IDENTIFY_VERIFIED_USER("identifyVerifiedUser"),
		TRACK_EVENT("trackEvent"),
		START_RECORDING("startRecording"),
		STOP_RECORDING("stopRecording"),
		PAUSE_RECORDING("pauseRecording"),
		RESUME_RECORDING("resumeRecording"),
		ADD_SESSION_PROPERTIES("addSessionProperties"),
		CLEAR_SESSION_PROPERTIES("clearSessionProperties"),
		RESUME_ALL_MONITORING("resumeAllMonitoring"),
		STOP_ALL_MONITORING("stopAllMonitoring"),
		TRACK_SCREEN_NAME("trackScreenName"),
		REGISTER_DEVICE_TOKEN("registerDeviceToken"),
		UNREGISTER_DEVICE("unregisterDevice"),
		LOGOUT("logout"),
		IS_USER_IDENTIFIED("isUserIdentified"),
        IS_CONFIGURED("isConfigured"),
        IS_RECORDING("isRecording"),
        IS_MONITORING("isMonitoring"),
        ARE_ON_DEMAND_SESSIONS_ENABLED("areOnDemandSessionsEnabled"),
		UPDATE_USER("updateUser"),
		START_TIMER("startTimer"),
		END_TIMER("endTimer"),
		PROCESS_PUSH_NOTIFICATION("processPushNotification"),
		UPDATE_TRANSITIONING_STATE("updateTransitioningState"),
		SET_IN_APP_LINK_HANDLER("setInAppLinkHandler"),
		SET_SHOULD_DISMISS_MODALS_ON_OPEN_LINK("setShouldDismissModalsOnOpenLink"),
		SET_IN_SCREEN_TRANSITIONING("setInScreenTransitioning"),
		SET_PREFERS_SYSTEM_THEME("setPrefersSystemTheme"),
		PAUSE_USER_INTERACTION_TRACKING("pauseUserInteractionTracking"),
		RESUME_USER_INTERACTION_TRACKING("resumeUserInteractionTracking"),
		CAPTURE_ERROR("captureError");

		companion object {
			val methodMap = values().associateBy { it.methodName }
		}
	}

	private fun <T> validateRequiredArgument(call: MethodCall, key: String): T {
		return call.argument<T>(key)
			?: throw IllegalArgumentException("Missing required argument: $key")
	}

	private fun <T> validateOptionalArgument(call: MethodCall, key: String, defaultValue: T): T {
		return call.argument<T>(key) ?: defaultValue
	}

	fun handle(call: MethodCall, result: MethodChannel.Result) {
		try {
			when (val method = Method.methodMap[call.method]) {
				Method.CONFIGURE -> configure(call, result)
				Method.UPDATE_FEATURE_CONFIGURATION -> updateFeatureConfiguration(call, result)
				Method.SHOW_SUPPORT -> showSupport(result)
				Method.CREATE_SUPPORT_CONVERSATION -> createSupportConversation(result)
				Method.IDENTIFY_ANONYMOUS_USER -> identifyAnonymousUser(call, result)
				Method.IDENTIFY_UNVERIFIED_USER -> identifyUnverifiedUser(call, result)
				Method.IDENTIFY_VERIFIED_USER -> identifyVerifiedUser(call, result)
				Method.TRACK_EVENT -> trackEvent(call, result)
				Method.START_RECORDING -> startRecording(result)
				Method.STOP_RECORDING -> stopRecording(result)
				Method.PAUSE_RECORDING -> pauseRecording(result)
				Method.RESUME_RECORDING -> resumeRecording(result)
				Method.ADD_SESSION_PROPERTIES -> addSessionProperties(call, result)
				Method.CLEAR_SESSION_PROPERTIES -> clearSessionProperties(result)
				Method.RESUME_ALL_MONITORING -> resumeAllMonitoring(result)
				Method.STOP_ALL_MONITORING -> stopAllMonitoring(result)
				Method.TRACK_SCREEN_NAME -> trackScreenName(call, result)
				Method.REGISTER_DEVICE_TOKEN -> registerDeviceToken(call, result)
				Method.UNREGISTER_DEVICE -> unregisterDevice(call, result)
				Method.LOGOUT -> logout(call, result)
				Method.IS_USER_IDENTIFIED -> isUserIdentified(result)
                Method.IS_CONFIGURED -> isConfigured(result)
                Method.IS_RECORDING -> isRecording(result)
                Method.IS_MONITORING -> isMonitoring(result)
                Method.ARE_ON_DEMAND_SESSIONS_ENABLED -> areOnDemandSessionsEnabled(result)
				Method.UPDATE_USER -> updateUser(call, result)
				Method.START_TIMER -> startTimer(call, result)
				Method.END_TIMER -> endTimer(call, result)
				Method.PROCESS_PUSH_NOTIFICATION -> processPushNotification(call, result)
				Method.UPDATE_TRANSITIONING_STATE -> updateTransitioningState(call, result)
				Method.SET_IN_APP_LINK_HANDLER -> setInAppLinkHandler(result)
				Method.SET_SHOULD_DISMISS_MODALS_ON_OPEN_LINK -> setShouldDismissModalsOnOpenLink(call, result)
				Method.SET_IN_SCREEN_TRANSITIONING -> setInScreenTransitioning(call, result)
				Method.SET_PREFERS_SYSTEM_THEME -> setPrefersSystemTheme(call, result)
				Method.PAUSE_USER_INTERACTION_TRACKING -> pauseUserInteractionTracking(result)
				Method.RESUME_USER_INTERACTION_TRACKING -> resumeUserInteractionTracking(result)
				Method.CAPTURE_ERROR -> captureError(call, result)
				else -> result.notImplemented()
			}
		} catch (e: IllegalArgumentException) {
			result.error("INVALID_ARGUMENT", e.message, null)
		} catch (e: Exception) {
			result.error("UNEXPECTED_ERROR", e.message, null)
		}
	}

	private fun processPushNotification(call: MethodCall, result: MethodChannel.Result) {
		val payload: String = validateRequiredArgument(call, "payload")
		DevRev.processPushNotification(context, payload)
		result.success(null)
	}

	private fun startTimer(call: MethodCall, result: MethodChannel.Result) {
		val name: String = validateRequiredArgument(call, "name")
		val properties: Map<String, String> = call.argument<Map<String, String>>("properties") ?: emptyMap()
		DevRev.startTimer(name, HashMap(properties))
		result.success(null)
	}

	private fun endTimer(call: MethodCall, result: MethodChannel.Result) {
		val name: String = validateRequiredArgument(call, "name")
		val properties: Map<String, String> = call.argument<Map<String, String>>("properties") ?: emptyMap()
		DevRev.endTimer(name, HashMap(properties))
		result.success(null)
	}

	private fun updateUser(call: MethodCall, result: MethodChannel.Result) {
		val identityMap: Map<String, Any> = validateRequiredArgument(call, "identity")
		val identity = IdentityParser.parseIdentity(identityMap)
		DevRev.updateUser(identity)
		result.success(null)
	}

	private fun configure(call: MethodCall, result: MethodChannel.Result) {
		val appID: String = validateRequiredArgument(call, "appID")
		val flutterVersion: String = validateOptionalArgument(call, "flutterVersion", "")
		val featureConfigurationMap = call.argument<Map<String, Any?>>("featureConfiguration")
		val featureConfiguration = FeatureConfigurationParser.parseFeatureConfiguration(featureConfigurationMap)

		if (featureConfiguration != null) {
			DevRev.configure(context, appID, featureConfiguration)
		} else {
			DevRev.configure(context, appID)
		}
		DevRev.setAppFrameworkInfo(context, "Flutter", flutterVersion)
		result.success(null)
	}

	private fun updateFeatureConfiguration(call: MethodCall, result: MethodChannel.Result) {
		val featureConfigurationMap: Map<String, Any?> = validateRequiredArgument(call, "featureConfiguration")
		val featureConfiguration = FeatureConfigurationParser.parseFeatureConfiguration(featureConfigurationMap)
			?: throw IllegalArgumentException("Invalid featureConfiguration")

		DevRev.updateFeatureConfiguration(context, featureConfiguration)
		result.success(null)
	}

	private fun isConfigured(result: MethodChannel.Result) {
		val isConfigured = DevRev.isConfigured
		result.success(isConfigured)
	}

	private fun showSupport(result: MethodChannel.Result) {
		DevRev.showSupport(context)
		result.success(null)
	}

	private fun createSupportConversation(result: MethodChannel.Result) {
		DevRev.createSupportConversation(context)
		result.success(null)
	}

	private fun identifyAnonymousUser(call: MethodCall, result: MethodChannel.Result) {
		val userID: String = validateRequiredArgument(call, "userID")
		DevRev.identifyAnonymousUser(userID)
		result.success(null)
	}

	private fun identifyUnverifiedUser(call: MethodCall, result: MethodChannel.Result) {
		val userID: String = validateRequiredArgument(call, "userID")
		val organizationId: String? = validateOptionalArgument(call, "organizationId", null)
		DevRev.identifyUnverifiedUser(
			Identity(userId = userID)
		)
		result.success(null)
	}

	private fun identifyVerifiedUser(call: MethodCall, result: MethodChannel.Result) {
		val userID: String = validateRequiredArgument(call, "userID")
		val sessionToken: String = validateRequiredArgument(call, "sessionToken")
		DevRev.identifyVerifiedUser(userID, sessionToken)
		result.success(null)
	}

	private fun isUserIdentified(result: MethodChannel.Result) {
		val isUserIdentified = DevRev.isUserIdentified
		result.success(isUserIdentified)
	}

	private fun trackEvent(call: MethodCall, result: MethodChannel.Result) {
		val name: String = validateRequiredArgument(call, "name")
		val properties = call.argument<Map<String, String>>("properties") ?: emptyMap()
		DevRev.trackEvent(name, HashMap(properties))
		result.success(null)
	}

	private fun startRecording(result: MethodChannel.Result) {
		DevRev.startRecording(context)
		result.success(null)
	}

	private fun stopRecording(result: MethodChannel.Result) {
		DevRev.stopRecording()
		result.success(null)
	}

	private fun pauseRecording(result: MethodChannel.Result) {
		DevRev.pauseRecording()
		result.success(null)
	}

	private fun resumeRecording(result: MethodChannel.Result) {
		DevRev.resumeRecording()
		result.success(null)
	}

	private fun isRecording(result: MethodChannel.Result) {
		val isRecording = DevRev.isRecording
		result.success(isRecording)
	}

	private fun addSessionProperties(call: MethodCall, result: MethodChannel.Result) {
		val properties = call.argument<Map<String, Any>>("properties") ?: emptyMap<String, Any>()
		DevRev.addSessionProperties(HashMap(properties))
		result.success(null)
	}

	private fun clearSessionProperties(result: MethodChannel.Result) {
		DevRev.clearSessionProperties()
		result.success(null)
	}

	private fun resumeAllMonitoring(result: MethodChannel.Result) {
		DevRev.resumeAllMonitoring()
		result.success(null)
	}

	private fun stopAllMonitoring(result: MethodChannel.Result) {
		DevRev.stopAllMonitoring()
		result.success(null)
	}

	private fun isMonitoring(result: MethodChannel.Result) {
		val isMonitoring = DevRev.isMonitoringEnabled
		result.success(isMonitoring)
	}

	private fun trackScreenName(call: MethodCall, result: MethodChannel.Result) {
		val screenName: String = validateRequiredArgument(call, "screenName")
		DevRev.trackScreenName(screenName)
		result.success(null)
	}

	private fun areOnDemandSessionsEnabled(result: MethodChannel.Result) {
		val areOnDemandSessionsEnabled = DevRev.areOnDemandSessionsEnabled
		result.success(areOnDemandSessionsEnabled)
	}

	private fun registerDeviceToken(call: MethodCall, result: MethodChannel.Result) {
		val deviceToken: String = validateRequiredArgument(call, "deviceToken")
		val deviceId: String = validateRequiredArgument(call, "deviceID")
		DevRev.registerDeviceToken(context, deviceToken, deviceId)
		result.success(null)
	}

	private fun unregisterDevice(call: MethodCall, result: MethodChannel.Result) {
		val deviceId: String = validateRequiredArgument(call, "deviceID")
		DevRev.unregisterDevice(context, deviceId)
		result.success(null)
	}

	private fun logout(call: MethodCall, result: MethodChannel.Result) {
		val deviceId: String = validateRequiredArgument(call, "deviceID")
		DevRev.logout(context, deviceId)
		result.success(null)
	}

	// It invokes onTransitionChangedListener, which is linked to MaskingProvider.changeTransitioningState via DevRevSDKFlutterPlugin
	private fun updateTransitioningState(call: MethodCall, result: MethodChannel.Result) {
		val isTransitioning = call.argument<Boolean>("state") ?: false
		onTransitionChangedListener?.invoke(isTransitioning)
		DevRev.setInScreenTransitioning(isTransitioning)
		result.success(null)
	}

	private fun setInAppLinkHandler(result: MethodChannel.Result) {
		try {
			inAppLinkHandler = { url ->
				val args = HashMap<String, Any>()
				args["url"] = url
				methodChannel.invokeMethod("inAppLinkReceived", args)
			}
			inAppLinkHandler?.let {
				DevRev.setInAppLinkHandler(it)
			}

			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun setPrefersSystemTheme(call: MethodCall, result: MethodChannel.Result) {
		try {
			val value = call.argument<Boolean>("value") ?: false
			DevRev.setShouldPreferSystemTheme(value)
			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun setShouldDismissModalsOnOpenLink(call: MethodCall, result: MethodChannel.Result) {
		try {
			val value = call.argument<Boolean>("value") ?: false
			DevRev.setShouldDismissModalsOnOpenLink(value)
			result.success(null)
		}
		catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun setInScreenTransitioning(call: MethodCall, result: MethodChannel.Result) {
		try {
			val value = call.argument<Boolean>("value") ?: false
			DevRev.setInScreenTransitioning(value)
			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun pauseUserInteractionTracking(result: MethodChannel.Result) {
		try {
			DevRev.pauseUserInteractionTracking()
			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun resumeUserInteractionTracking(result: MethodChannel.Result) {
		try {
			DevRev.resumeUserInteractionTracking()
			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}

	private fun captureError(call: MethodCall, result: MethodChannel.Result) {
		try {
			val error: String = validateRequiredArgument(call, "error")
			val stackTrace: String? = call.argument<String>("stackTrace")
			val tag: String = validateRequiredArgument(call, "tag")

			val throwable = if (stackTrace != null && stackTrace.isNotEmpty()) {
				val exception = RuntimeException(error)
				val stackTraceElements = stackTrace.split("\n")
					.filter { it.trim().isNotEmpty() }
					.map { StackTraceElement("", "", it.trim(), -1) }
					.toTypedArray()
				exception.stackTrace = stackTraceElements
				exception
			} else {
				RuntimeException(error)
			}

			DevRev.captureError(throwable, tag)
			result.success(null)
		} catch (e: Exception) {
			result.error("ERROR", e.message, null)
		}
	}
}
