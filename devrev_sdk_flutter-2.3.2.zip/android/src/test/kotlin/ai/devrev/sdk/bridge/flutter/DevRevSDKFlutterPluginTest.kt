package ai.devrev.sdk.bridge.flutter

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlin.test.Test
import org.mockito.Mockito

internal class DevRevSDKFlutterPluginTest {
}
