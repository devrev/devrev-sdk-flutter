# Contribution guide

- [Contribution guide](#contribution-guide)
  - [Requirements](#requirements)
  - [Development workflow](#development-workflow)
    - [Setting up the project](#setting-up-the-project)
    - [Running the example app](#running-the-example-app)
    - [Making changes to the plugin](#making-changes-to-the-plugin)
    - [Release process](#release-process)
      - [Test environment publishing](#test-environment-publishing)
      - [Test private packages](#test-private-packages)
      - [Publishing](#publishing)

## Requirements

- Flutter 3.3.0 or later.
- Dart SDK 3.7.0 or later.
- Android dependencies as required in the [Android SDK contribution guide](devrev/android-sdk-source/blob/main/CONTRIBUTING.md).
- iOS dependencies as required in the [iOS SDK contribution guide](devrev/ios-sdk-source/blob/main/CONTRIBUTING.md).
- An SSH key configured [locally on your machine and on GitHub](https://docs.github.com/en/github/authenticating-to-github/connecting-to-github-with-ssh) with an [enabled key for the DevRev organization](https://docs.github.com/en/github/authenticating-to-github/authorizing-an-ssh-key-for-use-with-saml-single-sign-on).

## Development workflow

### Setting up the project

To get started, clone the repository and install dependencies:

```sh
git clone git@github.com:devrev/flutter-sdk-source.git
cd flutter-sdk-source
flutter pub get
```

### Running the example app

This project includes an example app in the `example` directory to test the plugin functionality. To set up and run the example app:

1. Navigate to the `example` directory:
   ```sh
   cd example
   flutter clean
   ```

2. Install dependencies:
   ```sh
   flutter pub get
   ```
3. iOS app:
   Open the `example/ios/Runner.xcworkspace` in Xcode for running the iOS app or run the following command.
   ```sh
   flutter run -d ios
   ```
    Additional Steps for iOS before running the app:
    1. Change the minimum iOS deployment target version to `15.0`.
    2. Navigate to the `ios` directory and perform `pod install`.
    3. Open `example/ios/Runner.xcodeproj` in Xcode and select `Package dependencies -> FlutterGeneratedPluginSwiftPackage -> Package.swift` set iOS version from `12` to `15`.
       ```swift
       platforms: [
          .iOS("15.0")
       ]
       ```
    4. Perform `File -> Packages -> Resolve package versions`.
    5. Build and run the app.
4. Android app:
    Open the `android` directory in Android Studio or run the following command.
   ```sh
   flutter run -d android
   ```

### Making changes to the plugin

Changes to the plugin code in the `lib`, `ios` or `android` directories will be reflected in the example app after running the following commands in the `example` directory:

```sh
flutter clean
flutter pub get
```

### Release process
The publishing process is managed via the **Publish DevRev SDK for Flutter** GitHub workflow. This workflow allows you to publish the plugin as either a beta or public release.

#### Test environment publishing

The test publishing process is managed via the **Publish Package (`flutter_publish.yml`)** GitHub workflow. This workflow publishes the package to GitHub with a randomized version suffix (an epoch timestamp). No credentials are required, as they are shared as GitHub organization secrets.

Steps to publish a private version:
1. Update the version in `pubspec.yaml` to include a valid semantic version (e.g. `1.2.3`, `1.0.0-beta.1`).
2. Manually trigger the workflow by navigating to the GitHub repository.
   1. Select the `Actions` tab.
   2. Select the `Publish Package` workflow from the list.
   3. Click the `Run workflow` button. Note that you may need to select the branch you want to run the workflow on.

This will publish the package internally at [flutter-sdk-test](https://github.com/devrev/flutter-sdk-test), making it available for internal testing without affecting the stable release.

#### Test private packages
Add the internal Flutter package and the version you published to the dependencies:

```yaml
dependencies:
  devrev_sdk_flutter:
    git:
      url: git@github.com:devrev/flutter-sdk-test.git
      ref: <VERSION>
```

#### Publishing

The release process is managed via the **Publish Package (`flutter-publish.yml`)** GitHub workflow when
a new release is created in the GitHub repository, workflow will automatically publish the version.

Before Creating a Release, Make Sure to:
1. Bump the version in `pubspec.yaml`.
2. Update `CHANGELOG.md`.

This will publish the plugin to the public Flutter package registry.

Alternatively, workflow can be triggered manually from **Actions** tab with the `public_release` input set to `true`. No credentials are required, as they are shared as GitHub organization secrets.
