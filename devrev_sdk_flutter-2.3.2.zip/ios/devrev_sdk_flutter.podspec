require 'yaml'

pubspec_path = File.expand_path('../pubspec.yaml', __dir__)
pubspec = YAML.safe_load(File.read(pubspec_path))

version = pubspec['version']
plugin_description = pubspec['description'] || 'DevRev SDK Flutter bridge.'
ios_min_version =
  pubspec.dig(
    'flutter',
    'plugin',
    'platforms',
    'ios',
    'platformVersion'
  ) ||
  '15.0'
homepage = pubspec['homepage'] || 'https://devrev.ai'

Pod::Spec.new do |s|
  s.name             = 'devrev_sdk_flutter'
  s.version          = version
  s.summary          = plugin_description
  s.description      = <<-DESC
  #{plugin_description}
  DESC
  s.homepage         = homepage
  s.license          = { :type => 'Apache 2.0' }
  s.author           = { 'DevRev' => 'support@devrev.ai' }

  s.source           = { :path => '.' }
  s.source_files     = 'devrev_sdk_flutter/Sources/**/*.{swift}'

  s.ios.deployment_target = ios_min_version
  s.swift_version    = '5.9'
  s.static_framework = true

  s.dependency 'Flutter'
  s.dependency 'DevRevSDK', '2.3.5'
end
