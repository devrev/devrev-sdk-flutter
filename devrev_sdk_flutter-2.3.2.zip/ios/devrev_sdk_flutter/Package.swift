// swift-tools-version: 5.9
import PackageDescription

let package = Package(
	name: "devrev_sdk_flutter",
	platforms: [
		.iOS("15.0"),
	],
	products: [
		.library(
			name: "devrev-sdk-flutter",
			targets: ["devrev_sdk_flutter"]
		),
	],
	dependencies: [
		.package(
			url: "https://github.com/devrev/devrev-sdk-ios.git",
			exact: "2.3.5"
		),
	],
	targets: [
		.target(
			name: "devrev_sdk_flutter",
			dependencies: [
				.product(name: "DevRevSDK", package: "devrev-sdk-ios")
			],
			path: "Sources"
		),
	]
)
