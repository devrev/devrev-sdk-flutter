import Foundation
import Flutter
import UIKit
import DevRevSDK

/// A plugin class that bridges the DevRevSDK and the Flutter code.
public class DevRevSDKFlutterPlugin: NSObject, FlutterPlugin {
	// MARK: - Properties

	private let bridge: Bridge
	private static var maskingProvider: MaskingProvider?

	// MARK: - Lifecycle

	required init(
		bridge: Bridge = .init()
	){
		self.bridge = bridge
		super.init()
	}

	// MARK: - Plugin

	public static func register(
		with registrar: FlutterPluginRegistrar
	){
		let channelName = "devrev_sdk_flutter"
		let channel = FlutterMethodChannel(
			name: channelName,
			binaryMessenger: registrar.messenger()
		)

		let instance = DevRevSDKFlutterPlugin()
		instance.bridge.setMethodChannel(channel)
		registrar.addMethodCallDelegate(instance, channel: channel)

		maskingProvider = MaskingProvider(methodChannel: channel)
		instance.bridge.screenTransitioningDelegate = maskingProvider
	}

	// MARK: - Method Handling
	public func handle(
		_ call: FlutterMethodCall,
		result: @escaping FlutterResult
	){
		// Handling Methods
		guard
			let method = Bridge.Method(rawValue: call.method)
		else {
			result(FlutterMethodNotImplemented)
			return
		}

		do {
			guard
				method.isAsync
			else {
				let response = try bridge.handle(
					method,
					arguments: call.arguments as? [String: Any],
					completionHandler: nil
				)
				return result(response)
			}

			let _ = try bridge.handle(
				method,
				arguments: call.arguments as? [String: Any]
			){ response in
				result(response)
			}
		}
		catch let error as Bridge.Error {
			result(error.underlyingError)
		}
		catch {
			result(
				FlutterError(
					code: "UNEXPECTED_ERROR",
					message: error.localizedDescription,
					details: nil
				)
			)
		}
	}
}
