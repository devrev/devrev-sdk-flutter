import Foundation
import Flutter

extension Bridge {
	/// An error that can be thrown by the bridge.
	enum Error: Swift.Error {
		case invalidArguments(String)

		var underlyingError: FlutterError {
			.init(
				code: "INVALID_ARGUMENTS",
				message: String(describing: self),
				details: nil
			)
		}
	}
}
