import Foundation

extension Bridge {
	/// DevRevSDK methods supported by the bridge.
	enum Method: String {
		case configure
		case updateFeatureConfiguration
		case showSupport
        case createSupportConversation
		case identifyAnonymousUser
		case identifyUnverifiedUser
		case identifyVerifiedUser
		case trackEvent
		case startRecording
		case stopRecording
		case pauseRecording
		case resumeRecording
		case processAllOnDemandSessions
		case addSessionProperties
		case clearSessionProperties
		case resumeAllMonitoring
		case stopAllMonitoring
		case trackScreenName
        case registerDeviceToken
        case unregisterDevice
        case logout
        case isRecording
        case isMonitoring
        case areOnDemandSessionsEnabled
        case isUserIdentified
        case isConfigured
		case updateTransitioningState
		case endTimer
		case startTimer
		case updateUser
		case processPushNotification
		case setShouldDismissModalsOnOpenLink
		case setPrefersSystemTheme
        case setInAppLinkHandler
		case pauseUserInteractionTracking
		case resumeUserInteractionTracking
		case captureError

        var isAsync: Bool {
            switch self {
            case .isConfigured, .isUserIdentified:
                true
            default:
                false
            }
        }
	}


}
