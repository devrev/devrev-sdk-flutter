import Foundation
import Flutter
import DevRevSDK

/// A bridge between the Flutter plugin and the DevRev SDK.
class Bridge {
	// MARK: - Properties

	weak var screenTransitioningDelegate: ScreenTransitionDelegate?

	// MARK: - Argument validation

	private func validateRequiredArguments<T>(
		_ arguments: [String: Any]?,
		_ key: String
	) throws -> T {
		guard
			let arguments,
			let value = arguments[key] as? T
		else {
			throw Error.invalidArguments("\(key) of type \(T.self) is required")
		}

		return value
	}

	private func validateOptionalArguments<T>(
		_ arguments: [String: Any]?,
		_ key: String,
		defaultValue: T
	) -> T {
		guard
			let arguments,
			let value = arguments[key] as? T
		else {
			return defaultValue
		}

		return value
	}

	// MARK: - Parsing helpers

	private func parseSupportWidgetTheme(from dict: [String: Any]) -> SupportWidgetTheme {
		let prefersSystemTheme = dict["prefersSystemTheme"] as? Bool ?? true
		let primaryTextColor = dict["primaryTextColor"] as? String
		let accentColor = dict["accentColor"] as? String
		let spacingDict = dict["spacing"] as? [String: Any]
		let spacing = spacingDict?.compactMapValues { $0 as? String }

		return SupportWidgetTheme(
			prefersSystemTheme: prefersSystemTheme,
			primaryTextColor: primaryTextColor,
			accentColor: accentColor,
			spacing: spacing
		)
	}

	private func parseFeatureConfiguration(from dict: [String: Any]) throws -> FeatureConfiguration {
		let enableFrameCapture = dict["enableFrameCapture"] as? Bool ?? true
		let autoStartRecording = dict["autoStartRecording"] as? Bool ?? true
		let alwaysUseRemoteConfig = dict["alwaysUseRemoteConfig"] as? Bool ?? true
		let supportWidgetThemeDict = dict["supportWidgetTheme"] as? [String: Any]
		let supportWidgetTheme: SupportWidgetTheme
		if let themeDict = supportWidgetThemeDict {
			supportWidgetTheme = parseSupportWidgetTheme(from: themeDict)
		} else {
			supportWidgetTheme = SupportWidgetTheme.systemDefault
		}

		return FeatureConfiguration(
			enableFrameCapture: enableFrameCapture,
			autoStartRecording: autoStartRecording,
			alwaysUseRemoteConfig: alwaysUseRemoteConfig,
			supportWidgetTheme: supportWidgetTheme
		)
	}

	private var methodChannel: FlutterMethodChannel?

    func setMethodChannel(_ channel: FlutterMethodChannel) {
        self.methodChannel = channel
    }

	// MARK: - Method handling

	func handle(
		_ method: Method,
		arguments: [String: Any]?,
		completionHandler: ((Any) -> Void)?
	) throws -> Any? {
		switch method {
		case .configure:
			let appID: String = try validateRequiredArguments(
				arguments,
				"appID"
			)
			let flutterVersion: String = validateOptionalArguments(
				arguments,
				"flutterVersion",
				defaultValue: ""
			)
			let featureConfigurationDict = arguments?["featureConfiguration"] as? [String: Any]
			if let configDict = featureConfigurationDict {
				let featureConfiguration = try parseFeatureConfiguration(from: configDict)
				DevRevInterop.configure(
					appID: appID,
					featureConfiguration: featureConfiguration
				)
			} else {
				DevRevInterop.configure(appID: appID)
			}
			DevRevInterop.setAppFrameworkInfo(name: "Flutter", version: flutterVersion)
		case .updateFeatureConfiguration:
			let featureConfigurationDict: [String: Any] = try validateRequiredArguments(
				arguments,
				"featureConfiguration"
			)
			let featureConfiguration = try parseFeatureConfiguration(from: featureConfigurationDict)
			DevRevInterop.updateFeatureConfiguration(featureConfiguration)

		case .showSupport:
			let isAnimated = validateOptionalArguments(
				arguments,
				"isAnimated",
				defaultValue: true
			)
			DevRevInterop.showSupport(
				isAnimated: isAnimated
			)
		case .createSupportConversation:
			DevRevInterop.createSupportConversation()
		case .identifyAnonymousUser:
			let userID: String = try validateRequiredArguments(
				arguments,
				"userID"
			)
			DevRevInterop.identifyAnonymousUser(
				userID: userID
			)
		case .identifyUnverifiedUser:
			let userID: String = try validateRequiredArguments(
				arguments,
				"userID"
			)
			let organizationID: String? = validateOptionalArguments(
				arguments,
				"organizationID",
				defaultValue: nil
			)
			DevRevInterop.identifyUnverifiedUser(
				.init(
					userID: userID,
					organizationID: organizationID
				)
			)
		case .identifyVerifiedUser:
			let userID: String = try validateRequiredArguments(
				arguments,
				"userID"
			)
			let sessionToken: String = try validateRequiredArguments(
				arguments,
				"sessionToken"
			)
			DevRevInterop.identifyVerifiedUser(
				userID,
				sessionToken: sessionToken
			)
		case .trackEvent:
			let name: String = try validateRequiredArguments(
				arguments,
				"name"
			)
			let properties: [String: String] = try validateRequiredArguments(
				arguments,
				"properties"
			)
			DevRevInterop.trackEvent(
				name: name,
				properties: properties
			)
		case .addSessionProperties:
			let properties: [String: String] = try validateRequiredArguments(
				arguments,
				"properties"
			)
			DevRevInterop.addSessionProperties(
				properties
			)
		case .trackScreenName:
			let screenName: String = try validateRequiredArguments(
				arguments,
				"screenName"
			)
			DevRevInterop.trackScreenName(
				screenName
				)
		case .registerDeviceToken:
			let deviceToken: String = try validateRequiredArguments(
				arguments,
				"deviceToken"
			)
			let deviceID: String = try validateRequiredArguments(
				arguments,
				"deviceID"
			)
			DevRevInterop.registerDeviceToken(deviceToken, deviceID: deviceID)
		case .unregisterDevice:
			let deviceID: String = try validateRequiredArguments(
				arguments,
				"deviceID"
			)
			DevRevInterop.unregisterDevice(deviceID)
		case .logout:
			let deviceID: String = try validateRequiredArguments(
				arguments,
				"deviceID"
			)
			DevRevInterop.logout(deviceID: deviceID)
		case .startRecording:
			DevRevInterop.startRecording()
		case .stopRecording:
			DevRevInterop.stopRecording()
		case .pauseRecording:
			DevRevInterop.pauseRecording()
		case .resumeRecording:
			DevRevInterop.resumeRecording()
		case .processAllOnDemandSessions:
			DevRevInterop.processAllOnDemandSessions()
		case .clearSessionProperties:
			DevRevInterop.clearSessionProperties()
		case .resumeAllMonitoring:
			DevRevInterop.resumeAllMonitoring()
		case .stopAllMonitoring:
			DevRevInterop.stopAllMonitoring()
		case .isRecording:
			return DevRevInterop.isRecording
		case .isMonitoring:
			return DevRevInterop.isMonitoringEnabled
		case .areOnDemandSessionsEnabled:
			return DevRevInterop.areOnDemandSessionsEnabled
		case .isUserIdentified:
			Task {
				let result = await DevRevInterop.isUserIdentified
				completionHandler?(result)
			}
		case .startTimer:
			let name: String = try validateRequiredArguments(
				arguments,
				"name"
			)
			let properties: [String: String] = try validateRequiredArguments(
				arguments,
				"properties"
			)
			DevRevInterop.startTimer(name, properties: properties)
		case .endTimer:
			let name: String = try validateRequiredArguments(
				arguments,
				"name"
			)
			let properties: [String: String] = try validateRequiredArguments(
				arguments,
				"properties"
			)
			DevRevInterop.endTimer(name, properties: properties)
		case .processPushNotification:
			let payload: String = try validateRequiredArguments(
				arguments,
				"payload"
			)
			DevRevInterop.processPushNotification(payload)

		case .updateUser:
			let identityDict: [String: Any] = try validateRequiredArguments(
				arguments,
				"identity"
			)
            do {
                let data = try JSONSerialization.data(withJSONObject: identityDict, options: [])
                let identity = try JSONDecoder().decode(Identity.self, from: data)
                DevRevInterop.updateUser(identity)
            }
            catch {
                print(error)
            }

		case .isConfigured:
			Task {
				let result = await DevRevInterop.isConfigured
				completionHandler?(result)
			}
		case .updateTransitioningState:
			let state: Bool = try validateRequiredArguments(
				arguments,
				"state"
			)

			screenTransitioningDelegate?.isScreenTranistioning = state
		case .setShouldDismissModalsOnOpenLink:
			let value = try validateRequiredArguments(arguments, "value") as Bool
            DevRevInterop.shouldDismissModalsOnOpenLink = value
			completionHandler?(NSNull())
		case .setPrefersSystemTheme:
			let value = try validateRequiredArguments(arguments, "value") as Bool
            DevRevInterop.prefersSystemTheme = value
			completionHandler?(NSNull())
		case .setInAppLinkHandler:
			DevRevInterop.inAppLinkHandler = { [weak self] url in
				guard
					let self,
					let methodChannel
				else {
					return
				}
				let args: [String: Any] = ["url": url.absoluteString]
                methodChannel.invokeMethod("inAppLinkReceived", arguments: args)
			}
			completionHandler?(NSNull())
		case .pauseUserInteractionTracking:
			DevRevInterop.pauseUserInteractionTracking()
		case .resumeUserInteractionTracking:
			DevRevInterop.resumeUserInteractionTracking()
		case .captureError:
			let error: String = try validateRequiredArguments(arguments, "error")
			let stackTrace: String? = arguments?["stackTrace"] as? String
			let tag: String = try validateRequiredArguments(arguments, "tag")

			var userInfo: [String: Any] = [NSLocalizedDescriptionKey: error]
			let callStackSymbols = Thread.callStackSymbols

			if let stackTrace = stackTrace, !stackTrace.isEmpty {
				let stackTraceLines = stackTrace.components(separatedBy: "\n")
					.filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
				userInfo["NSCallStackSymbols"] = stackTraceLines
			} else {
				userInfo["NSCallStackSymbols"] = callStackSymbols
			}

			let nsError = NSError(domain: "DevRevSDK", code: 0, userInfo: userInfo)
			DevRevInterop.captureError(nsError, tag: tag)
			completionHandler?(NSNull())
		}

		return nil
	}
}

/// A protocol for updating the status of screen transitioning.
protocol ScreenTransitionDelegate: AnyObject {
	var isScreenTranistioning: Bool { get set }
}
