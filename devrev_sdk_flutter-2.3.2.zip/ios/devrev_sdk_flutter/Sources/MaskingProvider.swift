import Foundation
import Flutter
import DevRevSDK

class MaskingProvider : NSObject, ScreenTransitionDelegate, DevRev.MaskLocationProviding {
	// MARK: - Properties

	let methodChannel: FlutterMethodChannel
	var isScreenTranistioning: Bool = false

	// MARK: - Lifecycle

	init(methodChannel: FlutterMethodChannel) {
		self.methodChannel = methodChannel
		super.init()

		DevRev.setMaskingLocationProvider(self)
	}

	// MARK: - Masking

	func fetchMaskLocations(
		completionHandler: @escaping @Sendable (SnapshotMask) -> Void
	) {
		methodChannel.invokeMethod(
			"fetchFlutterData",
			arguments: ["mode": "basic"]
		) { result in
			guard
				!self.isScreenTranistioning,
				let payload = result as? [String: Any],
				let locations = payload["locations"] as? Array<Dictionary<String, String>>
			else {
				return
			}

			var snapshotMaskLocations = [SnapshotMask.Location]()

			for location in locations {
				guard
					let stringX = location["x"],
					let stringY = location["y"],
					let stringWidth = location["width"],
					let stringHeight = location["height"],
					let doubleX = Double(stringX),
					let doubleY = Double(stringY),
					let doubleWidth = Double(stringWidth),
					let doubleHeight = Double(stringHeight)
				else {
					continue
				}

				let maskRect = CGRect(
					x: CGFloat(doubleX),
					y: CGFloat(doubleY),
					width: CGFloat(doubleWidth),
					height: CGFloat(doubleHeight)
				)

				snapshotMaskLocations.append(.init(location: maskRect))
			}

			completionHandler(.init(
				locations: snapshotMaskLocations,
				shouldSkip: self.isScreenTranistioning
			))
		}
	}

	func provideSnapshotMask() async -> SnapshotMask {
		guard !isScreenTranistioning
		else {
			return .init(
				locations: [],
				shouldSkip: true
			)
		}

		return await withCheckedContinuation { continuation in
			fetchMaskLocations { mask in
				continuation.resume(returning: mask)
			}
		}
	}
}
