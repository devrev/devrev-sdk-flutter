import 'package:flutter/material.dart';

/// A GlobalKey with a unique UUID for identification.
class MaskGlobalKey extends GlobalKey {
  /// Unique identifier for this key.
  final String uuid;

  /// Creates a [MaskGlobalKey] with a unique [uuid].
  MaskGlobalKey()
      : uuid = UniqueKey().toString(),
        super.constructor();

  /// Returns the global bounds of the widget, or [Rect.zero] if unavailable.
  Rect get globalBounds {
    final ctx = currentContext;
    if (ctx == null) return Rect.zero;
    final renderBox = ctx.findRenderObject() as RenderBox?;
    if (renderBox == null) return Rect.zero;
    final offset = renderBox.localToGlobal(Offset.zero);
    final size = renderBox.size;
    return Rect.fromLTWH(offset.dx, offset.dy, size.width, size.height);
  }
}
