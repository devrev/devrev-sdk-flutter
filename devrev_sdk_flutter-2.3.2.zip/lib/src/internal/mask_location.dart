import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';

/// Represents a mask location with a unique identifier and rectangular bounds.
class MaskLocation {
  final String uuid;
  final Rect rect;

  /// Logical pixels to extend the mask left on Android (covers label edge / coordinate lag under fast transitions).
  static const double _androidLeftSlopLogical = 14.0;

  /// Reads DPR on each encode so the first frames and view changes are not stuck on a stale ratio.
  static double _androidDevicePixelRatio() {
    final views = PlatformDispatcher.instance.views;
    if (views.isEmpty) return 1.0;
    return views.first.devicePixelRatio;
  }

  /// Checks if the rectangle is valid (finite, non-empty, non-infinite).
  bool get isValid => rect.isFinite && !rect.isEmpty && !rect.isInfinite;

  const MaskLocation({required this.uuid, required this.rect});

  /// Converts the mask location to a JSON-compatible map, scaling coordinates by device pixel ratio.
  Map<String, String> get toJson {
    Rect r = rect;
    double scale = 1.0;
    if (Platform.isAndroid) {
      scale = _androidDevicePixelRatio();
      // Widen leftward so rapid transitions and sub-pixel rounding do not expose leading characters.
      r = Rect.fromLTRB(
        math.max(0.0, r.left - _androidLeftSlopLogical),
        r.top,
        r.right,
        r.bottom,
      );
    }
    return {
      'id': uuid,
      'x': (r.left * scale).toStringAsFixed(2),
      'y': (r.top * scale).toStringAsFixed(2),
      'width': (r.width * scale).toStringAsFixed(2),
      'height': (r.height * scale).toStringAsFixed(2),
    };
  }
}
