import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'mask_location.dart';

/// Controller for managing mask and unmask widget locations.
class MaskController {
  MaskController._();
  static final MaskController instance = MaskController._();

  final Map<String, MaskLocation> _masks = {};
  final Map<String, MaskLocation> _unmasks = {};

  void registerMask(String uuid, MaskLocation location) {
    try {
      _masks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to register mask with UUID $uuid. Error: $e',
      );
    }
  }

  void deregisterMask(String uuid) {
    try {
      _masks.remove(uuid);
    } catch (e) {
      debugPrint(
        'MaskController: Failed to deregister mask with UUID $uuid. Error: $e',
      );
    }
  }

  void updateMask(String uuid, MaskLocation location) {
    try {
      _masks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to update mask with UUID $uuid. Error: $e',
      );
    }
  }

  void registerUnmask(String uuid, MaskLocation location) {
    try {
      _unmasks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to register unmask with UUID $uuid. Error: $e',
      );
    }
  }

  void deregisterUnmask(String uuid) {
    try {
      _unmasks.remove(uuid);
    } catch (e) {
      debugPrint(
        'MaskController: Failed to deregister unmask with UUID $uuid. Error: $e',
      );
    }
  }

  void updateUnmask(String uuid, MaskLocation location) {
    try {
      _unmasks[uuid] = location;
    } catch (e) {
      debugPrint(
        'MaskController: Failed to update unmask with UUID $uuid. Error: $e',
      );
    }
  }

  /// Returns all valid mask locations, excluding unmasked ones.
  Map<String, dynamic> getLocations() {
    try {
      final locations = _masks.values
          .where(
            (location) => location.isValid && location.rect != Rect.zero,
          )
          .map((location) => location.toJson)
          .whereType<Map<String, String>>()
          .toList();
      return {'locations': locations};
    } catch (e) {
      debugPrint(
        'MaskController: Error retrieving batched mask locations. Error: $e',
      );
      return {'locations': []};
    }
  }
}
