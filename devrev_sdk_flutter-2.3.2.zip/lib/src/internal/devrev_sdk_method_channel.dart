import 'package:devrev_sdk_flutter/src/internal/mask_controller.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'devrev_sdk_method.dart';
import 'devrev_sdk_platform_interface.dart';
import 'sdk_version_generated.dart';
import '../feature_configuration.dart';

/// Native channels.
class Channels {
  static const MethodChannel channel = MethodChannel('devrev_sdk_flutter');
}

/// An implementation of [DevRevSDKPlatform] that uses method channels.
class MethodChannelDevRevSDK extends DevRevSDKPlatform {
  /// The method channel used to interact with the native platform.
  @visibleForTesting
  final MethodChannel methodChannel;
  bool isTransitioningState = false;
  void Function(String url)? _inAppLinkHandler;

  MethodChannelDevRevSDK({this.methodChannel = Channels.channel}) {
    methodChannel.setMethodCallHandler(_methodCallHandler);
  }

  /// Invokes the methods with the given arguments on the method channel.
  ///
  /// @param method The method to invoke.
  /// @param arguments The arguments to pass to the method.
  ///
  /// @returns The result of the method invocation.
  Future<T?> _invokeMethod<T>(
    DevRevSDKMethod method, [
    Map<String, dynamic>? arguments,
  ]) async {
    try {
      return await methodChannel.invokeMethod<T>(method.value, arguments);
    } catch (e) {
      debugPrint('DevRev method ${method.value} error: $e');
      return null;
    }
  }

  Future<dynamic> _methodCallHandler(MethodCall call) async {
    try {
      if (call.method == 'fetchFlutterData') {
        return MaskController.instance.getLocations();
      }
    } catch (e) {
      debugPrint(
        'MethodChannelDevRevSDK: methodCallHandler encountered an error: $e',
      );
    }
    return null;
  }

  @override
  Future<void> configure(
    String appID, [
    FeatureConfiguration? featureConfiguration,
  ]) async {
    final arguments = <String, dynamic>{
      'appID': appID,
      'flutterVersion': sdkVersion,
    };
    if (featureConfiguration != null) {
      arguments['featureConfiguration'] = featureConfiguration.toMap();
    }
    await _invokeMethod<void>(DevRevSDKMethod.configure, arguments);
  }

  @override
  Future<void> updateFeatureConfiguration(
    FeatureConfiguration featureConfiguration,
  ) async {
    await _invokeMethod<void>(
      DevRevSDKMethod.updateFeatureConfiguration,
      {'featureConfiguration': featureConfiguration.toMap()},
    );
  }

  @override
  Future<void> showSupport({bool isAnimated = true}) async {
    await _invokeMethod<void>(DevRevSDKMethod.showSupport, {
      'isAnimated': isAnimated,
    });
  }

  @override
  Future<void> createSupportConversation() async {
    await _invokeMethod<void>(DevRevSDKMethod.createSupportConversation);
  }

  @override
  Future<void> identifyAnonymousUser(String userID) async {
    await _invokeMethod<void>(DevRevSDKMethod.identifyAnonymousUser, {
      'userID': userID,
    });
  }

  @override
  Future<void> identifyUnverifiedUser(
    String userID,
    String? organizationID,
  ) async {
    await _invokeMethod<void>(DevRevSDKMethod.identifyUnverifiedUser, {
      'userID': userID,
      'organizationID': organizationID,
    });
  }

  @override
  Future<void> identifyVerifiedUser(String userID, String sessionToken) async {
    await _invokeMethod<void>(DevRevSDKMethod.identifyVerifiedUser, {
      'userID': userID,
      'sessionToken': sessionToken,
    });
  }

  @override
  Future<void> trackEvent(String name, Map<String, String> properties) async {
    await _invokeMethod<void>(DevRevSDKMethod.trackEvent, {
      'name': name,
      'properties': properties,
    });
  }

  @override
  Future<void> addSessionProperties(Map<String, String> properties) async {
    await _invokeMethod<void>(DevRevSDKMethod.addSessionProperties, {
      'properties': properties,
    });
  }

  @override
  Future<void> trackScreenName(String screenName) async {
    await _invokeMethod<void>(DevRevSDKMethod.trackScreenName, {
      'screenName': screenName,
    });
  }

  @override
  Future<void> startRecording() async {
    await _invokeMethod<void>(DevRevSDKMethod.startRecording);
  }

  @override
  Future<void> stopRecording() async {
    await _invokeMethod<void>(DevRevSDKMethod.stopRecording);
  }

  @override
  Future<void> pauseRecording() async {
    await _invokeMethod<void>(DevRevSDKMethod.pauseRecording);
  }

  @override
  Future<void> resumeRecording() async {
    await _invokeMethod<void>(DevRevSDKMethod.resumeRecording);
  }

  @override
  Future<void> processAllOnDemandSessions() async {
    await _invokeMethod<void>(DevRevSDKMethod.processAllOnDemandSessions);
  }

  @override
  Future<void> clearSessionProperties() async {
    await _invokeMethod<void>(DevRevSDKMethod.clearSessionProperties);
  }

  @override
  Future<void> resumeAllMonitoring() async {
    await _invokeMethod<void>(DevRevSDKMethod.resumeAllMonitoring);
  }

  @override
  Future<void> stopAllMonitoring() async {
    await _invokeMethod<void>(DevRevSDKMethod.stopAllMonitoring);
  }

  @override
  Future<void> registerDeviceToken(String deviceToken, String deviceID) async {
    await _invokeMethod<void>(DevRevSDKMethod.registerDeviceToken, {
      'deviceToken': deviceToken,
      'deviceID': deviceID,
    });
  }

  @override
  Future<void> unregisterDevice(String deviceID) async {
    await _invokeMethod<void>(DevRevSDKMethod.unregisterDevice, {
      'deviceID': deviceID,
    });
  }

  @override
  Future<void> logout(String deviceID) async {
    await _invokeMethod<void>(DevRevSDKMethod.logout, {'deviceID': deviceID});
  }

  @override
  Future<bool?> get isUserIdentified async {
    return _invokeMethod<bool>(DevRevSDKMethod.isUserIdentified);
  }

  @override
  Future<bool?> get isConfigured async {
    return _invokeMethod<bool>(DevRevSDKMethod.isConfigured);
  }

  @override
  Future<bool?> get isRecording async {
    return _invokeMethod<bool>(DevRevSDKMethod.isRecording);
  }

  @override
  Future<bool?> get isMonitoring async {
    return _invokeMethod<bool>(DevRevSDKMethod.isMonitoring);
  }

  @override
  Future<bool?> get areOnDemandSessionsEnabled async {
    return _invokeMethod<bool>(DevRevSDKMethod.areOnDemandSessionsEnabled);
  }

  @override
  Future<void> updateUser(Map<String, dynamic> identity) async {
    await _invokeMethod<void>(DevRevSDKMethod.updateUser, {
      'identity': identity,
    });
  }

  @override
  Future<void> startTimer(String name, Map<String, String> properties) async {
    await _invokeMethod<void>(DevRevSDKMethod.startTimer, {
      'name': name,
      'properties': properties,
    });
  }

  @override
  Future<void> endTimer(String name, Map<String, String> properties) async {
    await _invokeMethod<void>(DevRevSDKMethod.endTimer, {
      'name': name,
      'properties': properties,
    });
  }

  @override
  Future<void> processPushNotification(String payload) async {
    await _invokeMethod<void>(DevRevSDKMethod.processPushNotification, {
      'payload': payload,
    });
  }

  @override
  Future<void> updateTransitioningState(bool state) async {
    try {
      if (isTransitioningState != state) {
        isTransitioningState = state;
        await _invokeMethod(DevRevSDKMethod.updateTransitioningState, {
          'state': state,
        });
      }
    } catch (e) {
      debugPrint('MethodChannelDevRevSDK updateTransitioningState error: $e');
    }
  }

  @override
  Future<void> setInAppLinkHandler([void Function(String url)? handler]) async {
    _inAppLinkHandler = handler;
    methodChannel.setMethodCallHandler((call) async {
      if (call.method == "inAppLinkReceived") {
        final url = call.arguments['url'] as String;
        if (_inAppLinkHandler != null) {
          _inAppLinkHandler!(url);
        } else {
          debugPrint('Received in-app link: $url');
        }
        return null;
      } else {
        return _methodCallHandler(call);
      }
    });
    await _invokeMethod<void>(DevRevSDKMethod.setInAppLinkHandler);
  }

  @override
  Future<void> setShouldDismissModalsOnOpenLink(bool value) async {
    await _invokeMethod<void>(
      DevRevSDKMethod.setShouldDismissModalsOnOpenLink,
      {'value': value},
    );
  }

  @override
  Future<void> setPrefersSystemTheme(bool value) async {
    await _invokeMethod<void>(DevRevSDKMethod.setPrefersSystemTheme, {
      'value': value,
    });
  }

  @override
  Future<void> setInScreenTransitioning(bool value) async {
    await _invokeMethod<void>(DevRevSDKMethod.setInScreenTransitioning, {
      'value': value,
    });
  }

  @override
  Future<void> pauseUserInteractionTracking() async {
    await _invokeMethod<void>(DevRevSDKMethod.pauseUserInteractionTracking);
  }

  @override
  Future<void> resumeUserInteractionTracking() async {
    await _invokeMethod<void>(DevRevSDKMethod.resumeUserInteractionTracking);
  }

  @override
  Future<void> captureError(
    String error,
    String? stackTrace,
    String tag,
  ) async {
    await _invokeMethod<void>(DevRevSDKMethod.captureError, {
      'error': error,
      'stackTrace': stackTrace,
      'tag': tag,
    });
  }
}
