import 'package:plugin_platform_interface/plugin_platform_interface.dart';
import 'devrev_sdk_method_channel.dart';
import '../feature_configuration.dart';

abstract class DevRevSDKPlatform extends PlatformInterface {
  /// Constructs a DevRevSDKFlutterPlatform.
  DevRevSDKPlatform() : super(token: _token);

  static final Object _token = Object();

  static DevRevSDKPlatform _instance = MethodChannelDevRevSDK();

  /// The default instance of [DevRevSDKPlatform] to use.
  ///
  /// Defaults to [MethodChannelDevRevSDK].
  static DevRevSDKPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [DevRevSDKPlatform] when
  /// they register themselves.
  static set instance(DevRevSDKPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  /// Configures the SDK with the app ID and optional feature configuration.
  Future<void> configure(
    String appID, [
    FeatureConfiguration? featureConfiguration,
  ]) {
    throw UnimplementedError('configure() has not been implemented.');
  }

  Future<void> updateFeatureConfiguration(
    FeatureConfiguration featureConfiguration,
  ) {
    throw UnimplementedError(
      'updateFeatureConfiguration() has not been implemented.',
    );
  }

  Future<void> showSupport({bool isAnimated = true}) {
    throw UnimplementedError('showSupport() has not been implemented.');
  }

  Future<void> createSupportConversation() {
    throw UnimplementedError(
      'createSupportConversation() has not been implemented.',
    );
  }

  Future<void> identifyAnonymousUser(String userID) {
    throw UnimplementedError(
      'identifyAnonymousUser() has not been implemented.',
    );
  }

  Future<void> identifyUnverifiedUser(String userID, String? organizationID) {
    throw UnimplementedError(
      'identifyUnverifiedUser() has not been implemented.',
    );
  }

  Future<void> identifyVerifiedUser(String userID, String sessionToken) {
    throw UnimplementedError(
      'identifyVerifiedUser() has not been implemented.',
    );
  }

  Future<void> trackEvent(String name, Map<String, String> properties) {
    throw UnimplementedError('trackEvent() has not been implemented.');
  }

  Future<void> addSessionProperties(Map<String, String> properties) {
    throw UnimplementedError(
      'addSessionProperties() has not been implemented.',
    );
  }

  Future<void> trackScreenName(String screenName) {
    throw UnimplementedError('trackScreenName() has not been implemented.');
  }

  Future<void> startRecording() {
    throw UnimplementedError('startRecording() has not been implemented.');
  }

  Future<void> stopRecording() {
    throw UnimplementedError('stopRecording() has not been implemented.');
  }

  Future<void> pauseRecording() {
    throw UnimplementedError('pauseRecording() has not been implemented.');
  }

  Future<void> resumeRecording() {
    throw UnimplementedError('resumeRecording() has not been implemented.');
  }

  Future<void> processAllOnDemandSessions() {
    throw UnimplementedError(
      'processAllOnDemandSessions() has not been implemented.',
    );
  }

  Future<void> clearSessionProperties() {
    throw UnimplementedError(
      'clearSessionProperties() has not been implemented.',
    );
  }

  Future<void> resumeAllMonitoring() {
    throw UnimplementedError('resumeAllMonitoring() has not been implemented.');
  }

  Future<void> stopAllMonitoring() {
    throw UnimplementedError('stopAllMonitoring() has not been implemented.');
  }

  Future<void> registerDeviceToken(String deviceToken, String deviceID) {
    throw UnimplementedError('registerDeviceToken() has not been implemented.');
  }

  Future<void> unregisterDevice(String deviceID) {
    throw UnimplementedError('unregisterDevice() has not been implemented.');
  }

  Future<void> logout(String deviceID) {
    throw UnimplementedError('logout() has not been implemented.');
  }

  Future<bool?> get isUserIdentified {
    throw UnimplementedError('isUserIdentified has not been implemented.');
  }

  Future<bool?> get isConfigured {
    throw UnimplementedError('isConfigured has not been implemented.');
  }

  Future<bool?> get isRecording {
    throw UnimplementedError('isRecording has not been implemented.');
  }

  Future<bool?> get isMonitoring {
    throw UnimplementedError('isMonitoring has not been implemented.');
  }

  Future<bool?> get areOnDemandSessionsEnabled {
    throw UnimplementedError(
      'areOnDemandSessionsEnabled has not been implemented.',
    );
  }

  Future<void> startTimer(String name, Map<String, String> properties) {
    throw UnimplementedError('startTimer() has not been implemented.');
  }

  Future<void> endTimer(String name, Map<String, String> properties) {
    throw UnimplementedError('endTimer() has not been implemented.');
  }

  Future<void> updateUser(Map<String, dynamic> identity) {
    throw UnimplementedError('updateUser() has not been implemented.');
  }

  Future<void> processPushNotification(String payload) {
    throw UnimplementedError(
      'processPushNotification() has not been implemented.',
    );
  }

  Future<void> updateTransitioningState(bool state) {
    throw UnimplementedError(
      'updateTransitioningState() has not been implemented.',
    );
  }

  Future<void> setInAppLinkHandler([void Function(String url)? handler]) {
    throw UnimplementedError('setInAppLinkHandler() has not been implemented.');
  }

  Future<void> setShouldDismissModalsOnOpenLink(bool value) {
    throw UnimplementedError(
      'setShouldDismissModalsOnOpenLink() has not been implemented.',
    );
  }

  Future<void> setPrefersSystemTheme(bool value) {
    throw UnimplementedError(
      'setPrefersSystemTheme() has not been implemented.',
    );
  }

  Future<void> setInScreenTransitioning(bool value) {
    throw UnimplementedError(
      'setInScreenTransitioning() has not be implemented.',
    );
  }

  Future<void> pauseUserInteractionTracking() {
    throw UnimplementedError(
      'pauseUserInteractionTracking() has not been implemented.',
    );
  }

  Future<void> resumeUserInteractionTracking() {
    throw UnimplementedError(
      'resumeUserInteractionTracking() has not been implemented.',
    );
  }

  Future<void> captureError(String error, String? stackTrace, String tag) {
    throw UnimplementedError('captureError() has not been implemented.');
  }
}
