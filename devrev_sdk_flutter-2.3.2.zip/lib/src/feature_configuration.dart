import 'dart:io' show Platform;

/// Configuration for the support widget theme.
///
/// Use this to customize the support widget's appearance,
/// including colors, spacing, and theme preferences.
class SupportWidgetTheme {
  /// Whether to prefer the system theme (light/dark mode).
  final bool prefersSystemTheme;

  /// Primary text color as a hex string (e.g., '#000000').
  final String? primaryTextColor;

  /// Accent color as a hex string (e.g., '#FF5733').
  final String? accentColor;

  /// Spacing configuration (e.g., {'bottom': '20px', 'side': '15px'}).
  final Map<String, String>? spacing;

  const SupportWidgetTheme({
    required this.prefersSystemTheme,
    this.primaryTextColor,
    this.accentColor,
    this.spacing,
  });

  /// Default theme that prefers system theme.
  static const SupportWidgetTheme systemDefault = SupportWidgetTheme(
    prefersSystemTheme: true,
  );

  /// Converts the theme to a map for platform communication.
  Map<String, dynamic> toMap() {
    return {
      'prefersSystemTheme': prefersSystemTheme,
      if (primaryTextColor != null) 'primaryTextColor': primaryTextColor,
      if (accentColor != null) 'accentColor': accentColor,
      if (spacing != null) 'spacing': spacing,
    };
  }
}

/// Configuration for DevRev SDK features.
///
/// Use this to customize SDK behavior: frame capture,
/// auto-start recording, dialog mode (Android only), and support widget theme.
class FeatureConfiguration {
  /// Whether to enable frame capture.
  final bool enableFrameCapture;

  /// Whether to automatically start recording.
  final bool autoStartRecording;

  /// Whether to always use remote config.
  final bool alwaysUseRemoteConfig;

  /// Whether to prefer dialog mode (Android only). Ignored on iOS.
  final bool prefersDialogMode;

  /// Theme configuration for the support widget.
  final SupportWidgetTheme supportWidgetTheme;

  const FeatureConfiguration({
    required this.enableFrameCapture,
    required this.autoStartRecording,
    required this.alwaysUseRemoteConfig,
    required this.prefersDialogMode,
    required this.supportWidgetTheme,
  });

  /// Converts the configuration to a map for platform communication.
  Map<String, dynamic> toMap() {
    return {
      'enableFrameCapture': enableFrameCapture,
      'autoStartRecording': autoStartRecording,
      'alwaysUseRemoteConfig': alwaysUseRemoteConfig,
      if (Platform.isAndroid) 'prefersDialogMode': prefersDialogMode,
      'supportWidgetTheme': supportWidgetTheme.toMap(),
    };
  }
}
