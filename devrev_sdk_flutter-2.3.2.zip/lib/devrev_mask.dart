import 'dart:io';
import 'devrev.dart';
import '../src/internal/mask_location.dart';
import '../src/internal/mask_controller.dart';
import '../src/internal/mask_global_key.dart';
import 'package:flutter/material.dart';
import 'dart:async';

typedef MaskRegisteredCallback = void Function(
    String uuid, MaskLocation location);
typedef MaskUpdatedCallback = void Function(String uuid, MaskLocation location);
typedef MaskDeregisteredCallback = void Function(String uuid);

abstract class _BaseMaskWidget extends StatefulWidget {
  final Widget child;
  final MaskRegisteredCallback onMaskRegistered;
  final MaskUpdatedCallback onMaskUpdated;
  final MaskDeregisteredCallback onMaskDeregistered;

  const _BaseMaskWidget({
    super.key,
    required this.child,
    required this.onMaskRegistered,
    required this.onMaskUpdated,
    required this.onMaskDeregistered,
  });
}

abstract class _BaseMaskState<T extends _BaseMaskWidget> extends State<T>
    with WidgetsBindingObserver {
  late final MaskGlobalKey _maskGlobalKey = MaskGlobalKey();
  Rect _previousLocation = Rect.zero;
  Timer? _debounceTimer;

  MaskLocation get location =>
      MaskLocation(uuid: _maskGlobalKey.uuid, rect: _cachedGlobalBounds);

  Rect get _cachedGlobalBounds =>
      mounted ? _maskGlobalKey.globalBounds : Rect.zero;

  @override
  void initState() {
    super.initState();

    // Ensure that the DevRev SDK is configured before proceeding.
    if (!DevRev.isSDKConfigured) {
      debugPrint(
        'DevRev SDK is not configured. Please call DevRev.configure() before using DevRevMask or DevRevUnmask.',
      );
      return;
    }

    // We need to ensure that the transition state is set to true initially.
    DevRev.updateTransitioningState(true);

    final loc = location;
    // If the initial location is zero, we set it to the current bounds.
    if (_previousLocation == Rect.zero) {
      _previousLocation = loc.rect;
    }

    widget.onMaskRegistered(_maskGlobalKey.uuid, loc);
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback(_updateRecursivelyIfNeeded);

    // This is particularly useful for Android where the transition state needs to be managed.
    // We set it to false after the initial registration, and want native SDK to capture the frame.
    if (Platform.isAndroid) {
      // Give it a small buffer to ensure registration is processed.
      _debounce(() => DevRev.updateTransitioningState(false),
          const Duration(milliseconds: 100));
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounceTimer?.cancel();
    widget.onMaskDeregistered(_maskGlobalKey.uuid);
    super.dispose();
  }

  // Debounce to delay the action and avoid excessive calls.
  void _debounce(VoidCallback action, Duration duration) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(duration, action);
  }

  void _updateRecursivelyIfNeeded(Duration _) {
    MaskLocation currentLocation = location;
    if (currentLocation.rect != _previousLocation) {
      // Adjust the location for landscape mode.
      currentLocation = _adjustLocationForLandscape(currentLocation);

      _previousLocation = currentLocation.rect;
      widget.onMaskUpdated(_maskGlobalKey.uuid, currentLocation);
    }

    // We schedule another post frame callback to catch further changes.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Recursive call is important to ensure we catch all changes.
      _updateRecursivelyIfNeeded(Duration.zero);
    });
  }

  void _updateLocationAndTransitionState(Duration _) {
    MaskLocation currentLocation = location;
    if (currentLocation.rect != _previousLocation) {
      // Adjust the location for landscape mode.
      currentLocation = _adjustLocationForLandscape(currentLocation);

      _previousLocation = currentLocation.rect;
      widget.onMaskUpdated(_maskGlobalKey.uuid, currentLocation);
    }

    // Enable frame capture at the native SDK after a short delay.
    _debounce(
      () => DevRev.updateTransitioningState(false),
      const Duration(milliseconds: 200),
    );
  }

  /// Adjusts the mask location for landscape orientation.
  /// This modifies the width of the rectangle to cover the whole masked area in landscape mode.
  /// This is particularly useful for Android devices where the mask might need to be wider at right side in landscape.
  MaskLocation _adjustLocationForLandscape(MaskLocation location) {
    if (Platform.isAndroid) {
      // Check if the widget is mounted to avoid accessing context when not available.
      if (!mounted) return location;

      if (MediaQuery.of(context).orientation == Orientation.landscape) {
        return MaskLocation(
          uuid: location.uuid,
          rect: Rect.fromLTRB(
            location.rect.left,
            location.rect.top,
            location.rect.right + 50, // Adjust width for landscape.
            location.rect.bottom,
          ),
        );
      }
    }
    return location;
  }

  @override
  KeyedSubtree build(BuildContext context) =>
      KeyedSubtree(key: _maskGlobalKey, child: widget.child);

  @override
  void didChangeMetrics() {
    // Disable the frame capture at the native SDK when the metrics change.
    DevRev.updateTransitioningState(true);

    WidgetsBinding.instance.addPostFrameCallback(
      _updateLocationAndTransitionState,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    DevRev.updateTransitioningState(true);

    // App has resumed, update the mask state.
    if (state == AppLifecycleState.resumed) {
      WidgetsBinding.instance.addPostFrameCallback(
        _updateLocationAndTransitionState,
      );
    }
  }
}

class DevRevMask extends _BaseMaskWidget {
  DevRevMask({super.key, required super.child})
      : super(
          onMaskRegistered: MaskController.instance.registerMask,
          onMaskUpdated: MaskController.instance.updateMask,
          onMaskDeregistered: MaskController.instance.deregisterMask,
        );

  @override
  State<DevRevMask> createState() => _DevRevMaskState();
}

class _DevRevMaskState extends _BaseMaskState<DevRevMask> {}

class DevRevUnmask extends _BaseMaskWidget {
  DevRevUnmask({super.key, required super.child})
      : super(
          onMaskRegistered: MaskController.instance.registerUnmask,
          onMaskUpdated: MaskController.instance.updateUnmask,
          onMaskDeregistered: MaskController.instance.deregisterUnmask,
        );

  @override
  State<DevRevUnmask> createState() => _DevRevUnmaskState();
}

class _DevRevUnmaskState extends _BaseMaskState<DevRevUnmask> {}
