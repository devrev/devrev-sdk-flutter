import 'package:flutter/material.dart';
import '../../devrev.dart';

class DevRevMonitoredApp extends MaterialApp {
  DevRevMonitoredApp({
    super.key,
    super.navigatorKey,
    super.scaffoldMessengerKey,
    super.home,
    super.routes,
    super.initialRoute,
    super.onGenerateRoute,
    super.onGenerateInitialRoutes,
    super.onUnknownRoute,
    List<NavigatorObserver> navigatorObservers = const [],
    Widget Function(BuildContext, Widget?)? builder,
    super.title,
    super.onGenerateTitle,
    super.color,
    super.theme,
    super.darkTheme,
    super.highContrastTheme,
    super.highContrastDarkTheme,
    super.themeMode,
    super.themeAnimationDuration,
    super.themeAnimationCurve,
    super.locale,
    super.localizationsDelegates,
    super.localeListResolutionCallback,
    super.localeResolutionCallback,
    super.supportedLocales,
    super.debugShowMaterialGrid,
    super.showPerformanceOverlay,
    super.checkerboardRasterCacheImages,
    super.checkerboardOffscreenLayers,
    super.showSemanticsDebugger,
    super.debugShowCheckedModeBanner,
    super.shortcuts,
    super.actions,
    super.restorationScopeId,
    // Kept for backward compatibility with older Flutter versions, but not passed to super
    // to avoid deprecation warnings in Flutter 3.7.0+ (parameter is ignored by MaterialApp)
    bool useInheritedMediaQuery = false,
  }) : super(
          builder: (context, child) {
            Widget content = builder != null
                ? builder(context, child)
                : child ?? const SizedBox.shrink();
            return NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  DevRev.updateTransitioningState(true);
                } else if (notification is ScrollEndNotification) {
                  DevRev.updateTransitioningState(false);
                }
                return false;
              },
              child: content,
            );
          },
          navigatorObservers: [
            DevRevTransitionTrackingObserver(),
            ...navigatorObservers,
          ],
        );

  DevRevMonitoredApp.router({
    super.key,
    super.scaffoldMessengerKey,
    super.routerConfig,
    super.routeInformationProvider,
    super.routeInformationParser,
    super.routerDelegate,
    super.backButtonDispatcher,
    Widget Function(BuildContext, Widget?)? builder,
    super.title,
    super.onGenerateTitle,
    super.color,
    super.theme,
    super.darkTheme,
    super.highContrastTheme,
    super.highContrastDarkTheme,
    super.themeMode,
    super.themeAnimationDuration,
    super.themeAnimationCurve,
    super.locale,
    super.localizationsDelegates,
    super.localeListResolutionCallback,
    super.localeResolutionCallback,
    super.supportedLocales,
    super.debugShowMaterialGrid,
    super.showPerformanceOverlay,
    super.checkerboardRasterCacheImages,
    super.checkerboardOffscreenLayers,
    super.showSemanticsDebugger,
    super.debugShowCheckedModeBanner,
    super.shortcuts,
    super.actions,
    super.restorationScopeId,
    // Kept for backward compatibility with older Flutter versions, but not passed to super
    // to avoid deprecation warnings in Flutter 3.7.0+ (parameter is ignored by MaterialApp)
    bool useInheritedMediaQuery = false,
  }) : super.router(
          builder: (context, child) {
            Widget content = builder != null
                ? builder(context, child)
                : child ?? const SizedBox.shrink();
            return NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification is ScrollStartNotification) {
                  DevRev.updateTransitioningState(true);
                } else if (notification is ScrollEndNotification) {
                  DevRev.updateTransitioningState(false);
                }
                return false;
              },
              child: content,
            );
          },
        );
}

/// A NavigatorObserver that tracks route transitions and updates the DevRev SDK
/// transitioning state accordingly.
///
/// This observer should be added to GoRouter's `observers` list when using
/// `DevRevMonitoredApp.router` with GoRouter to ensure proper transition tracking.
///
/// Example:
/// ```dart
/// final router = GoRouter(
///   routes: [...],
///   observers: [DevRevTransitionTrackingObserver()],
/// );
/// ```
class DevRevTransitionTrackingObserver extends NavigatorObserver {
  void _attachTransitionListener(Route<dynamic> route) {
    if (route is PageRoute && route.animation != null) {
      route.animation!.addStatusListener((status) {
        switch (status) {
          case AnimationStatus.forward:
          case AnimationStatus.reverse:
            DevRev.updateTransitioningState(true);
            break;
          case AnimationStatus.completed:
          case AnimationStatus.dismissed:
            DevRev.updateTransitioningState(false);
            break;
        }
      });
    }
  }

  @override
  void didPush(Route route, Route? previousRoute) {
    _attachTransitionListener(route);
    super.didPush(route, previousRoute);
  }

  @override
  void didPop(Route route, Route? previousRoute) {
    _attachTransitionListener(previousRoute ?? route);
    super.didPop(route, previousRoute);
  }

  @override
  void didReplace({Route? newRoute, Route? oldRoute}) {
    if (newRoute != null) _attachTransitionListener(newRoute);
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
  }
}
